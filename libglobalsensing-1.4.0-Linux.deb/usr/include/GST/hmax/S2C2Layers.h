/*
* File:   S2C2Layers.h
* Author: olivier
*
* Created on 22 octobre 2014, 23:19
*/

#ifndef S2C2LAYERS_H
#define    S2C2LAYERS_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include <vector>
#include <map>
#include <opencv2/core/core.hpp>
#include <ostream>
#include <istream>
#include "GST/core/Readable.h"
#include "GST/core/Writable.h"
#include "GST/hmax/core/S2TrainerStrategy.h"
#include "GST/hmax/core/S2ProcessStrategy.h"

#define S2C2LAYERS_ORIGINAL 20150128
#define S2C2LAYERS_V2       20150326

namespace gst
{

/**
* Combination of HMAX S2 and C2 layers.
*
* This class abstracts the behaviors of the S2 and C2 layers of the HMAX
* framework. For more information, see original HMAX paper.
*
* To use it, one must first create an instance of the S2C2Layers object, by
* using its constructor. Once it's been instanciated, one
* may call the train() method which takes care of the patch extraction in the
* C1 images at random positions. Once this is done, the user can call the
* process() function, that will apply both the S2 and C2 layers in a row to the
* input C1 images. The user can also call again the train() method - the
* newly extracted patches shall be added to the ones extracted before.
*
* This class also provides utility functions. The isTrained() method returns
* true if the S2 layer has been trained, and false otherwise. The
* getNbOrientations() returns the number of orientations in the patches - if
* the S1 class was used with the default parameters, getNbOrientations()
* returns 4. Finally, getNbPatches() returns the total number of patches that were
* learnt by the object.
*/
class S2C2Layers : public Readable, public Writable
{

public:

    /**
    * Constructor.
    */
    DLLEXP S2C2Layers();

    /**
    * Constructor.
    *
    * Construct object with data from input stream.
    *
    * @param is input stream to read
    */
    DLLEXP S2C2Layers(std::istream& is, long version);

    DLLEXP S2C2Layers(S2TrainerStrategy* s2TrainerStrategy, S2ProcessStrategy* s2ProcessStrategy);

    /**
    * Destructor.
    */
    DLLEXP virtual ~S2C2Layers() {}

    /**
    * Write dictionnary data in output stream.
    *
    * @param os output stream where to write.
    */
    DLLEXP void write(std::ostream& os) const;

    /**
    * Read dictionnary data from input stream.
    *
    * @param is input stream from where to read.
    */
    DLLEXP void read(std::istream& is);

    DLLEXP void read(std::istream& is, long version);

    /**
    * Create S2C2Layers instance with parameters read from input stream.
    *
    * This method is used by the HMaxLoader class, and should not be called directly.
    *
    * @param version id of the S2C2Layers object to read from stream.
    * @return a pointer to the newly created instance
    */
    DLLEXP static S2C2Layers* load(long version, std::istream& is) { return new S2C2Layers(is, version); }

    /**
   * Apply S2 layer to input C1 patches.
   *
   * This function is pure virtual, and must be implemented by the subclass.
   *
   * @param c1 input c1 patches to process
   * @param out pointer to output vector where to write the results
   */
    DLLEXP virtual void process(const std::vector<std::vector<cv::Mat> >& c1,
                                std::vector<float>* out)
                                const { s2ProcessStrategy->process(c1, patches, out); }

    /**
   * Train the S2 layer of the object.
   *
   * @param c1 input image in C1 space
   * @param pSizes sizes of the patches to extract
   */
    DLLEXP void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1) { s2TrainerStrategy->train(c1, &patches); }

    /**
   * Returns true if S2 layer have been trained, false otherwise
   * @return
   */
    DLLEXP bool isTrained() const { return !patches.empty(); }

    /**
   * Get number of orientations
   *
   * @return
   */
    DLLEXP size_t getNbOrientations() const { return isTrained() ? patches.front().size() : 0; }

    /**
   * Get number of patch learnt in S2.
   *
   * @return number of patches
   */
    DLLEXP size_t getNbPatches() const { return patches.size(); }

    DLLEXP void exportPatchesAsImages(const std::string& prefix) const;


private:

    /**
    * Learnt patches.
    *
    * The first dimension corresponds the patch, and the second to the
    * orientations.
    */
    std::vector<std::vector<cv::Mat> > patches;

    S2TrainerStrategy* s2TrainerStrategy;

    S2ProcessStrategy* s2ProcessStrategy;

};

}

#endif    /* S2C2LAYERS_H*/

