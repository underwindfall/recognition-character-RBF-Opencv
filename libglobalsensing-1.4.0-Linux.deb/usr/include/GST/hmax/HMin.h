/*
* File:   HMin.h
* Author: olivier
*
* Created on 22 octobre 2014, 23:19
*/

#ifndef HMIN_H
#define    HMIN_H

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

#include "GST/hmax/S1Layer.h"
#include "GST/hmax/C1Layer.h"
#include "GST/core/Readable.h"
#include "GST/core/Writable.h"
#include <string>

namespace gst
{

    /**
   * Abstracts the HMin framework.
   *
   * This class provides an implementation of the HMin framework. For more
   * information see HMin original paper ("Robust object recognition with
   * cortex-like mechanisms", Serre et al.).
   *
   * To use this class, one first needs to instantiate it, using one of its
   * constructors. Unless the user is only interested in the S1 and C1 layer,
   * the object must be trained; that can be done with the train() method, .
   *
   * Once the object has been trained at least once, and only then, the user may
   * call the s1c1s2c2 method, which apply the whole HMin process on the input
   * image. If the object isn't trained, only the s1c1 method may be called.
   */
    class HMin : public Writable
    {

    public:

        DLLEXP HMin() : s1Layer(new S1Layer()), c1Layer(new C1Layer()) {}

        /**
       * Constructor.
       *
       * Creates a HMin object with default parameters. The user still needs to
       * provide the beta parameter of the S2 layer, as no default parameter is
       * proposed in HMin paper.
       */
        DLLEXP HMin(AbstractS1Layer* s1Layer, AbstractC1Layer* c1Layer) : s1Layer(s1Layer), c1Layer(c1Layer) {}

        DLLEXP HMin(const HMin& orig) : s1Layer(orig.s1Layer->clone()), c1Layer(orig.c1Layer->clone()) {}

        DLLEXP HMin& operator=(const HMin& orig);

        /**
       * Destructor.
       */
        DLLEXP virtual ~HMin();

        DLLEXP virtual void write(std::ostream& os) const;

        DLLEXP virtual void write(const std::string& path) const { Writable::write(path); }

        DLLEXP void process(const cv::Mat& im, std::vector<float>* out) const;

        DLLEXP void setS1Layer(AbstractS1Layer* s1Layer);

        DLLEXP void setC1Layer(AbstractC1Layer* c1Layer);

    private:

        AbstractS1Layer* s1Layer;

        AbstractC1Layer* c1Layer;

    };

}

#endif    /* HMIN_H*/

