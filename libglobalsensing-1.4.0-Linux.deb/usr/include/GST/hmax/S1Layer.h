/*
* File:   S1Layer.h
* Author: olivier
*
* Created on 22 octobre 2014, 23:18
*/

#ifndef S1LAYER_H
#define    S1LAYER_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include <vector>
#include <istream>
#include <ostream>
#include <opencv2/opencv.hpp>
#include "GST/hmax/core/AbstractS1Layer.h"

#define S1LAYER_ORIGINAL 20140128
#define S1LAYER_CUSTOMCODE 20150204
#define DEFAULT_CV_TYPE CV_32F
#define DEFAULT_FILTER_MAX_VALUE -1.0f

namespace gst
{

/**
* Implements the S1 layer of HMAX framework.
*
* This class provides the features needed to apply the S1 layer of HMAX
* to an image, which is in fact a Gabor filter bank to it. See "Robust Object
* Detection with Cortex-Like Mechanisms" paper (Serre et al.) for more
* information.
*
* To use it, one first needs to instanciate it, simply by calling S1Layer().
* It creates a S1Layer object with default filters, such as described in Serre
* et al.'s paper. One can also set custom filter parameters, by specifying them
* when calling the corresponding constructor. Once the class has been
* instantiated, process() may be called to apply the filter bank to the input image.
*/
class S1Layer : public AbstractS1Layer
{
public:

    /**
    * Constructor.
    *
    * Creates a S1Layer object with 64 gabor filters, 16 scales and
    * 4 orientations, with the parameters given in the original HMAX paper.
    */
    DLLEXP S1Layer();

    DLLEXP S1Layer(std::istream& is) { read(is); }

    /**
    * Constructor.
    *
    * Creates a S1Layer object with as many filters as the number of scales
    * times the number of orientations. The number of scales is given by the
    * size of the filtersSizes, sigmas and lambdas vectors, which must be equal.
    * The number of orientations is given by the size of thetas.
    *
    * The i-th element of the filtersSizes, sigmas and lambdas vectors are the
    * parameters of the filters of the i-th scale. Thus, filtersSizes[0],
    * sigmas[0] and lambdas[0] are used to create the first scale filters;
    * filtersSizes[1], sigmas[1] and lambdas[1] are used to create the second
    * scale filters, and so on until filtersSizes.back(), sigmas.back() and
    * lambdas.back().
    *
    * The vectors filtersSizes, sigmas and lambdas must all have the same size.
    *
    * @param filtersSizes sizes of the filters' kernels
    * @param sigmas standard deviations of the filters' kernels
    * @param lambdas wavelength of the filters's kernels
    * @param gamma aspect ratio
    * @param thetas orientations of the filters' kernels, in radians
    */
    DLLEXP S1Layer(const std::vector<size_t>& filtersSizes,
                   const std::vector<float>& sigmas,
                   const std::vector<float>& lambdas,
                   const float gamma,
                   const std::vector<float>& thetas);

    /**
    * Constructor.
    *
    * Construct object with data from stream.
    *
    * @param is input stream to read
    */
    DLLEXP S1Layer(std::istream& is, int version);

    /**
    * Create a deep copy of a C1Layer instance.
    *
    * @return a pointer to a deep copy of a C1Layer instance.
    */
    DLLEXP virtual AbstractS1Layer* clone() const { return new S1Layer(*this); }

    /**
    * Destructor
    */
    DLLEXP virtual ~S1Layer() {}

    /**
    * Apply filter bank to input image.
    *
    * This method applies the filter bank on the input image. The results are
    * stored in the output vector pointed to by the out parameter.
    *
    * out is a 2D vector. The first dimension corresponds to the orientation,
    * and the second one to the scale. Thus, out[i][j] gives the output of
    * the Gabor filter with the i-th orientation and j-scale. Note that the
    * input image is not resized, and no histogram equalization is performed.
    *
    * The input image must be a grayscale image of the type set during
    * instantiation of the S1 object (default is CV_32F).
    *
    * @param im input image
    * @param out filters' outputs
    */
    DLLEXP void process(const cv::Mat im,
                std::vector<std::vector<cv::Mat> >* out) const;

    /**
    * Write C1 layer parameters to stream.
    *
    * @param os stream where to write data
    */
    DLLEXP void write(std::ostream& os) const;

    /**
    * Read S1 layer parameters from stream.
    *
    * We assume that we read from a file containing the right S1Layer
    * sub-type.
    *
    * @param is stream from where to read data
    * @param version specifies the version of the S1 layer to read from stream
    */
    DLLEXP void read(std::istream& is, int version);

    /**
    * Read S1 layer parameters from stream.
    *
    * We assume that we read from a file containing the right S1Layer
    * sub-type.
    *
    * @param is stream from where to read data
    */
    DLLEXP void read(std::istream& is);

    /**
    * Create S1Layer instance with parameters read from input stream.
    *
    * This method is used by the HMaxLoader class, and should not be called directly.
    *
    * @param version id of the S1Layer object to read from stream.
    * @return a pointer to the newly created instance
    */
    DLLEXP static AbstractS1Layer* load(long version, std::istream& is) { return new S1Layer(is, version); }


protected:

    /**
    * Initialazation function called by constructors.
    *
    * See constructors' documentation.
    */
    DLLEXP virtual void init(const std::vector<size_t>& filtersSizes,
              const std::vector<float>& sigmas,
              const std::vector<float>& lambdas,
              const float gamma,
              const std::vector<float>& thetas);

    /**
    * Gabor filters kernels used for input image filtering.
    */
    std::vector<std::vector<cv::Mat> > gaborFilterKernels;

    // Store data to allow to save easily
    std::vector<size_t> filtersSizes;
    std::vector<float> sigmas;
    std::vector<float> lambdas;
    float gamma;
    std::vector<float> thetas;

};

}

#endif    /* S1LAYER_H*/

