/*
* File:   HMax.h
* Author: olivier
*
* Created on 22 octobre 2014, 23:19
*/

#ifndef HMAX_H
#define    HMAX_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include "GST/hmax/S1Layer.h"
#include "GST/hmax/C1Layer.h"
#include "GST/hmax/S2C2Layers.h"
#include "GST/hmax/core/HMaxStrategy.h"
#include "GST/core/Readable.h"
#include <string>

namespace gst
{

/**
* Abstracts the HMAX framework.
*
* This class provides an implementation of the HMAX framework. For more
* information see HMAX original paper ("Robust object recognition with
* cortex-like mechanisms", Serre et al.).
*
* To use this class, one first needs to instantiate it, using one of its
* constructors. Unless the user is only interested in the S1 and C1 layer,
* the object must be trained; that can be done with the train() method, .
*
* Once the object has been trained at least once, and only then, the user may
* call the s1c1s2c2 method, which apply the whole HMax process on the input
* image. If the object isn't trained, only the s1c1 method may be called.
*/
class HMax : public HMaxStrategy, public Readable
{

public:

    /**
    * Constructor.
    *
    * Creates a HMax object with default parameters. The user still needs to
    * provide the beta parameter of the S2 layer, as no default parameter is
    * proposed in HMax paper.
    */
    DLLEXP HMax();

    /**
    * Constructor.
    *
    * Construct HMax object with data read from given input stream.
    *
    * @param is input stream from which to read the data
    */
    DLLEXP HMax(std::istream& is);

    /**
    * Constructor.
    *
    * Construct HMax object with data read from input file.
    *
    * @param path path to input file from which to read the data
    */
    DLLEXP HMax(const std::string& path);

    /**
    * Destructor.
    */
    DLLEXP virtual ~HMax() {}

    /**
    * DEPRECATED Read HMAX parameters from input stream.
    *
    * This method is deprecated, because it is not as HMaxLoader::Load().
    * To load HMAX data from a stream, see HMaxLoader class.
    *
    * @param is input stream handle
    * @see HMaxLoader
    */
    DLLEXP virtual void read(std::istream& is);

    /**
    * DEPRECATED Read HMAX parameters from file.
    *
    * This method is deprecated, because it is not as HMaxLoader::Load().
    * To load HMAX data from a file, see HMaxLoader class.
    *
    * @param path to input file
    * @see HMaxLoader
    */
    DLLEXP virtual void read(const std::string& path) { Readable::read(path); }

};

}

#endif    /* HMAX_H*/

