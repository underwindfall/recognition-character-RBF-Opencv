#ifndef HAAR_H
#define HAAR_H

#include <opencv2/core/core.hpp>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

/**
* Single level Haar decomposition of image.
*
* @param outCH pointer to output image (horizontal component)
* @param outCV pointer to output image (vertical component)
* @param outCD pointer to output image (diagonal component)
* @param im input image
*/
void dhaart2(cv::Mat* outCH, cv::Mat* outCV, cv::Mat* outCD, const cv::Mat& im);


#endif /* HAAR_H*/
