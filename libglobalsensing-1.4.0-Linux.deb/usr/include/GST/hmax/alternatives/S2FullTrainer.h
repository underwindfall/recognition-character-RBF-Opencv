#ifndef S2FULLTRAINER_H
#define S2FULLTRAINER_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include "GST/hmax/core/S2TrainerStrategy.h"
#include "S2FeatureSelector.h"
#include <set>

#define NB_FEATURES_DEFAULT 200

namespace gst
{

class S2FullTrainer : public S2TrainerStrategy
{

public:

    DLLEXP S2FullTrainer(const std::set<size_t>& patchSizes = {4, 8, 12, 16}) : patchSizes(patchSizes) {}

    DLLEXP void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1, std::vector<std::vector<cv::Mat>>*out);

    static const long ID = 201503271;

    DLLEXP virtual long getId() const { return ID; }


private:

    std::set<size_t> patchSizes;

};

}

#endif /* S2FULLTRAINER_H*/
