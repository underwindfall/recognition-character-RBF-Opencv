#ifndef S2FEATURESELECTOR_H
#define S2FEATURESELECTOR_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include <vector>
#include <opencv2/opencv.hpp>

namespace gst
{

class S2FeatureSelector
{

public:

    DLLEXP S2FeatureSelector(size_t nbFeaturesToKeep) : nbFeaturesToKeep(nbFeaturesToKeep) {}

    DLLEXP void select(const std::vector<std::vector<cv::Mat> >& in, std::vector<std::vector<cv::Mat>>* out);

    DLLEXP static void vectorizeData(const std::vector<cv::Mat>& in, std::vector<double>* out);


private:

    size_t nbFeaturesToKeep;

};

}

#endif /* S2FEATURESELECTOR_H*/
