#ifndef S2YUSLOTINEPERSCALETRAINER_H
#define S2YUSLOTINEPERSCALETRAINER_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include "GST/hmax/core/S2RandomTrainer.h"
#include "S2FeatureSelector.h"

#define NB_FEATURES_PER_SCALE_DEFAULT 250

namespace gst
{

    class S2YuSlotinePerScaleTrainer : public S2RandomTrainer
    {

    public:

        DLLEXP S2YuSlotinePerScaleTrainer(const std::map<size_t, size_t>& pSizes, const S2FeatureSelector& s2FeatureSelector = S2FeatureSelector(NB_FEATURES_PER_SCALE_DEFAULT)) : S2RandomTrainer(pSizes), s2FeatureSelector(s2FeatureSelector) {}

        DLLEXP S2YuSlotinePerScaleTrainer(const S2FeatureSelector& s2FeatureSelector = S2FeatureSelector(NB_FEATURES_PER_SCALE_DEFAULT)) : s2FeatureSelector(s2FeatureSelector) {}

        DLLEXP void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1, std::vector<std::vector<cv::Mat>>*out);

        static const long ID = 20150416;

        DLLEXP virtual long getId() const { return ID; }


    private:

        S2FeatureSelector s2FeatureSelector;

    };

}

#endif /* S2YUSLOTINEPERSCALETRAINER_H*/
