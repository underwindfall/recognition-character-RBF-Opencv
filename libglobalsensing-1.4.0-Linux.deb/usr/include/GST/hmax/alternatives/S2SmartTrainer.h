#ifndef S2SMARTTRAINER_H
#define S2SMARTTRAINER_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include "GST/hmax/core/S2TrainerStrategy.h"
#include "GST/hmax/alternatives/S2FullTrainer.h"
#include "S2FeatureSelector.h"
#include <set>

#define NB_FEATURES_DEFAULT 200

namespace gst
{

class S2SmartTrainer : public S2FullTrainer
{

public:

    DLLEXP S2SmartTrainer(const S2FeatureSelector& s2FeatureSelector = S2FeatureSelector(NB_FEATURES_DEFAULT), const std::set<size_t>& patchSizes = {4, 8, 12, 16}) : s2FeatureSelector(s2FeatureSelector), S2FullTrainer(patchSizes) {}

    DLLEXP void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1, std::vector<std::vector<cv::Mat>>*out);

    static const long ID = 201503262;

    DLLEXP virtual long getId() const { return ID; }


private:

    S2FeatureSelector s2FeatureSelector;

};

}

#endif /* S2SMARTTRAINER_H*/
