#ifndef HMAXYUSLOTINE_H
#define HMAXYUSLOTINE_H

#include <GST/hmax/core/HMaxStrategy.h>
#include <GST/hmax/alternatives/S1LayerHaar.h>
#include <GST/hmax/C1Layer.h>
#include <GST/hmax/S2C2Layers.h>
#include <GST/hmax/core/S2ProcessOriginal.h>
#include <GST/hmax/alternatives/S2YuSlotineTrainer.h>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{

/**
* Implementation of the optimsations proposed by Yu and Slotine.
*
* This class proposes an implementation of the optimisations presented
* in "FastWavelet-Based Visual Classification" (Yu et al., 19th International
* Conference on Pattern Recognition, 2008. ICPR 2008).
*/
class HMaxYuSlotine : public HMaxStrategy
{

public:

    /**
    * Constructor.
    */
    DLLEXP HMaxYuSlotine() : HMaxStrategy(new S1LayerHaar(),
                                          new C1Layer(C1_NB_LAYER_POOLING, C1_POOLING_WINDOWS_SIZES, C1_STEPS),
                                          new S2C2Layers(new S2YuSlotineTrainer(), new S2ProcessOriginal())) {}

};

}

#endif /* HMAXYUSLOTINE_H*/
