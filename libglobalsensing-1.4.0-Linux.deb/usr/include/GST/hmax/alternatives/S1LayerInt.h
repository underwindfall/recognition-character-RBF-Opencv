#ifndef S1LAYERINT_H
#define S1LAYERINT_H

#include "GST/hmax/S1Layer.h"
#include <istream>

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

namespace gst
{

class S1LayerInt : public S1Layer
{

public:

    DLLEXP S1LayerInt(size_t gaborCoeffWordLength = 2, size_t inputImWordLength = 8, size_t outputImWordLength = 8);

    DLLEXP S1LayerInt(std::istream& is) { read(is); }

    DLLEXP AbstractS1Layer* clone() const { return new S1LayerInt(*this); }

    DLLEXP void process(const cv::Mat im, std::vector<std::vector<cv::Mat> >* out) const;


private:

    DLLEXP void convertKernels();

    size_t gaborCoeffWordLength;

    size_t inputImWordLength;

    size_t outputImWordLength;

};

}

#endif /* S1LAYERINT_H*/
