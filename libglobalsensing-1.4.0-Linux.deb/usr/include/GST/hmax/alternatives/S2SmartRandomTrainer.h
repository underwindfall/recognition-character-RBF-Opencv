#ifndef S2SMARTRANDOMTRAINER_H
#define S2SMARTRANDOMTRAINER_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include "GST/hmax/alternatives/S2FullTrainer.h"
#include "S2FeatureSelector.h"
#include <set>

#define NB_FEATURES_DEFAULT 200

namespace gst
{

class S2SmartRandomTrainer : public S2FullTrainer
{

public:

    DLLEXP S2SmartRandomTrainer(const std::set<size_t>& patchSizes = {4, 8, 12, 16}, float threshold = 20.0f, size_t nbFeaturesToSelect = 200) : S2FullTrainer(patchSizes), threshold(threshold), nbFeaturesToSelect(nbFeaturesToSelect) {}

    DLLEXP void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1, std::vector<std::vector<cv::Mat>>*out);

    static const long ID = 20150327;

    DLLEXP virtual long getId() const { return ID; }


private:

    float threshold;

    size_t nbFeaturesToSelect;

};

}

#endif /* S2SMARTTRAINER_H*/
