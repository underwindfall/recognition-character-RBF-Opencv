#ifndef S2YUSLOTINETRAINER_H
#define S2YUSLOTINETRAINER_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include "GST/hmax/core/S2RandomTrainer.h"
#include "S2FeatureSelector.h"

#define NB_FEATURES_DEFAULT 200

namespace gst
{

class S2YuSlotineTrainer : public S2RandomTrainer
{

public:

    DLLEXP S2YuSlotineTrainer(const std::map<size_t, size_t>& pSizes, const S2FeatureSelector& s2FeatureSelector = S2FeatureSelector(NB_FEATURES_DEFAULT)) : S2RandomTrainer(pSizes), s2FeatureSelector(s2FeatureSelector) {}

    DLLEXP S2YuSlotineTrainer(const S2FeatureSelector& s2FeatureSelector = S2FeatureSelector(NB_FEATURES_DEFAULT)) : s2FeatureSelector(s2FeatureSelector) {}

    DLLEXP void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1, std::vector<std::vector<cv::Mat>>*out);

    static const long ID = 201503261;

    DLLEXP virtual long getId() const { return ID; }


private:

    S2FeatureSelector s2FeatureSelector;

};

}

#endif /* S2YUSLOTINETRAINER_H*/
