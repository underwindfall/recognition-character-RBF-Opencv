/*
* File:   S1LayerHaar.h
* Author: olivier
*
* Created on 12 octobre 2015, 15:53
*/

#ifndef S1LAYERHAAR_H
#define    S1LAYERHAAR_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include "GST/hmax/core/AbstractS1Layer.h"

#define S1LAYER_HAAR_VERSION 20150212

/**
* Default number of scales in decomposition.
*/
#define DEFAULT_NBSCALES 3

// Those macros are useful to configure C1 layer
#define C1_NB_LAYER_POOLING 1
#define C1_POOLING_WINDOWS_SIZES gst::S1LayerHaar::getC1PoolingWindowsSizes()
#define C1_STEPS gst::S1LayerHaar::getC1Steps()

namespace gst
{

/**
* S1 layer implementation using Haar wavelet decomposition.
*
* This class implements a version of the optimization proposed in
* "FastWavelet-Based Visual Classification" (Yu and Slotine,
* 19th International Conference on Pattern Recognition, 2008. ICPR 2008),
* where images are decomposed with wavelets. In this version, the Haar wavelet
* are used. By default, the number of scales in the decomposition is given
* by the DEFAULT_NBSCALES macro.
*
* When using this class as the S1 layer, specific parameters must be used
* for the C1Layer - it won't work with the parameters given in
* "Robust object recognition with cortex-like mechanisms" (Serre et al.,
* Pattern Analysis and Machine Intelligence, IEEE Transactions on).
* However, macro are defined to use as correct parameters for the C1 layer.
* Those macros are C1_NB_LAYER_POOLING, C1_POOLING_WINDOWS_SIZE and C1_STEPS.
*/
class S1LayerHaar : public AbstractS1Layer
{

public:

    /**
    * Constructor.
    *
    * Creates an S1LayerHaar object, and initializes nbScales, by default to
    * DEFAULT_NBSCALES. This constructor may be used as the default constructor.
    *
    * @param nbScales number of scales in decomposition.
    */
    DLLEXP S1LayerHaar(size_t nbScales = DEFAULT_NBSCALES) : nbScales(nbScales) {}

    /**
    * Construct S1LayerHaar object with data from stream.
    *
    * This constructor simply calls read().
    *
    * @param is input stream from which to read.
    * @see read()
    */
    DLLEXP S1LayerHaar(std::istream& is) { read(is); }

    /**
    * Implementation of AbstractS1Layer::clone().
    *
    * @see AbstractS1Layer::clone()
    */
    DLLEXP virtual AbstractS1Layer* clone() const { return new S1LayerHaar(*this); }

    /**
    * Destructor.
    */
    DLLEXP virtual ~S1LayerHaar() {}

    /**
    * Apply multi-scales haar decomposition to input image.
    *
    * This methods expects the input image to be grayscale, and
    * of type CV_8U.
    * See AbstractS1Layer::process() for more information about the
    * output data format.
    *
    * @param im input image
    * @param out pointer where to write output images
    */
    DLLEXP void process(const cv::Mat im,
                        std::vector<std::vector<cv::Mat> >* out) const;

    /**
    * Read parameters from input stream.
    *
    * @param is input stream from which to read data
    */
    DLLEXP virtual void read(std::istream& is);

    /**
    * Write class instance parameters to output stream.
    *
    * @param os output stream to which to write the data
    */
    DLLEXP virtual void write(std::ostream& os) const;

    /**
    * Creates an instance of this class with data from stream.
    *
    * This function creates a new instance of this class with the
    * data read from the given input stream handle.
    *
    * This method is needed by the HMaxLoader class, and should not
    * be used directly.
    *
    * @param version version number of the object to instantiate
    * @param is input stream from which to read data
    */
    DLLEXP static AbstractS1Layer* load(long version, std::istream& is) { return new S1LayerHaar(is); }

    DLLEXP static std::vector<size_t> getC1PoolingWindowsSizes();

    DLLEXP static std::vector<size_t> getC1Steps();


private:

    /**
    * Number of decomposition scales.
    */
    size_t nbScales;

};

}

#endif    /* S1LAYERHAAR_H*/

