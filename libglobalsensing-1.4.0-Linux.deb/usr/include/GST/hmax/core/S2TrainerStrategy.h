#ifndef S2TRAINERSTRATEGY_H
#define S2TRAINERSTRATEGY_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include <vector>
#include <map>
#include <opencv2/opencv.hpp>

namespace gst
{

class S2TrainerStrategy
{

public:

    DLLEXP virtual ~S2TrainerStrategy() {}

    DLLEXP virtual void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1, std::vector<std::vector<cv::Mat>>*out) = 0;

    DLLEXP virtual long getId() const = 0;

};

}

#endif /* S2TRAINERSTRATEGY_H*/
