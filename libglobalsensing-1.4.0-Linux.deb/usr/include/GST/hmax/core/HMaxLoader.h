/*
* File:   HMaxLoader.h
* Author: olivier
*
* Created on 12 february 2015, 11:22
*/

#ifndef HMAXLOADER_H
#define HMAXLOADER_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include "GST/hmax/core/HMaxStrategy.h"
#include "GST/hmax/HMin.h"
#include <map>
#include <istream>
/********
******* HMin à des fonctions virtuelles non définies ici ce qui semble poser des soucis
********/
namespace gst
{

typedef AbstractS1Layer* (*S1Loader)(long, std::istream& is);
typedef AbstractC1Layer* (*C1Loader)(long, std::istream& is);
typedef S2C2Layers* (*S2C2Loader)(long, std::istream& is);

/**
* Provides methods allowing to load HMaxStrategy instance.
*
* To load an HMaxStrategy instance having built-in subclasses,
* one simply needs to call load(). If the user implemented its own
* subclass of either AbstractS1Layer, AbstractC1Layer or AbstractS2C2Layers,
* those classes must first be registered with addS1Loader(), addC1Loader()
* and/or addS2C2Loader().
*
* This class uses the Singleton design pattern.
*/
class HMaxLoader
{

public:

    /**
    * Load HMaxStrategy instance from input stream.
    *
    * This method loads a previously written HMaxStrategy instance
    * and write the results in the out pointer. There is no need
    * to know a priori which implementations of the S1, C1, S2 and C2
    * layers were written; it is deduced from the read data.
    *
    * @param is the input stream from which to read the data
    * @param out pointer to output results
    */
    DLLEXP static HMaxStrategy* loadHMax(std::istream& is);

    /**
    * Load HMaxStrategy instance from file.
    *
    * This method opens the file at the given path, read it using the
    * "stream version" of the load method, then closes the file.
    *
    * @param path path to file to read
    * @param out pointer where to write data
    * @see load()
    */
    DLLEXP static HMaxStrategy* loadHMax(const std::string& path);

    DLLEXP static HMin* loadHMin(const std::string& path);

    DLLEXP static HMin* loadHMin(std::istream& is);

    /* <DEPRECATED>*/
    DLLEXP static void load(std::istream& is, HMaxStrategy* out);
    DLLEXP static void load(const std::string& path, HMaxStrategy* out);
    DLLEXP static void load(const std::string& path, HMin* out);
    DLLEXP static void load(std::istream& is, HMin* out);
    /* </DEPRECATED>*/

    /**
    * Registers an S1 loader.
    *
    * This methods adds the given loader to the s1Loaders list. A loader
    * is a pointer to a function of type S1Loader. The version parameter
    * can be any arbitrary unique integer: if one tries to map a loaderFunction
    * to an already existing version number, an exception is thrown.
    *
    * @param version number to map to loaderFunction
    * @param loaderFunction pointer to function that takes care of the loading
    */
    DLLEXP static void addS1Loader(long version, S1Loader loaderFunction);

    /**
    * Registers an C1 loader.
    *
    * This methods adds the given loader to the C1Loaders list. A loader
    * is a pointer to a function of type C1Loader. The version parameter
    * can be any arbitrary unique integer: if one tries to map a loaderFunction
    * to an already existing version number, an exception is thrown.
    *
    * @param version number to map to loaderFunction
    * @param loaderFunction pointer to function that takes care of the loading
    */
    DLLEXP static void addC1Loader(long version, C1Loader loaderFunction);

    /**
    * Registers an S2C2 loader.
    *
    * This methods adds the given loader to the s1Loaders list. A loader
    * is a pointer to a function of type S1Loader. The version parameter
    * can be any arbitrary unique integer: if one tries to map a loaderFunction
    * to an already existing version number, an exception is thrown.
    *
    * @param version number to map to loaderFunction
    * @param loaderFunction pointer to function that takes care of the loading
    */
    DLLEXP static void addS2C2Loader(long version, S2C2Loader loaderFunction);


private:

    /**
    * Default constructor.
    */
    HMaxLoader();

    /**
    * List of S1Loader function pointers and their associated version number.
    */
    std::map<long, S1Loader> s1Loaders;

    /**
    * List of C1Loader function pointers and their associated version number.
    */
    std::map<long, C1Loader> c1Loaders;

    /**
    * List of S2C2Loader function pointers and their associated version number.
    */
    std::map<long, S2C2Loader> s2C2Loaders;

    /**
    * Unique instance of class.
    */
    static HMaxLoader instance;

};

}

#endif /* HMAXLOADER_H*/
