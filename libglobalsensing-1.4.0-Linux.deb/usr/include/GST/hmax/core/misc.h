/*
* File:   misc.h
* Author: olivier
*
* Created on 22 octobre 2014, 23:20
*/

#ifndef MISC_H
#define    MISC_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include <opencv2/core/core.hpp>
#include <istream>
#include <ostream>

namespace gst
{

    /**
    * Create Gabor filter kernel.
    *
    * This function creates a Gabor filter kernel as in "Robust Objet
    * Recognition with Cortex-Like Mechanism" (Serre et al.).
    *
    * size must be odd; appart from that, there is no particuar restrictions
    * on the parameters.
    *
    * @param size width and height of the kernel in pixels
    * @param sigma standard deviation of the kernel's gaussian
    * @param lambda wavelength
    * @param gamma aspect ratio
    * @param theta orientation in radians
    */
    DLLEXP void createGaborKernel(size_t size, float sigma, float lambda,
                              float gamma, float theta, cv::Mat* out);

    /**
    * Apply maximum filter to input image.
    *
    * This function applies a max filter on the input image. The filters consist
    * in the following: we consider the pixels inside the square located
    * on the (0,0) pixel (i.e the top left corner) and of size windowSize. We
    * only keep the maximum pixel value in this square. Then we move the square
    * a certain amount of pixels to the right (defined by the step arguement),
    * and we keep, again, only the maximum pixel value, and so on.
    *
    * The input matrix doesn't need to be of a particular type; however it must
    * be 2D (i.e it must have only 1 channel). The output matrix is of type
    * CV_64F, meaning "double".
    *
    * @param imin input image
    * @param imout pointer to the output image
    * @param windowSize size of the sliding window
    * @param step distance between the present position of the window and the next one
    */
    DLLEXP void maxFilter(const cv::Mat imin, cv::Mat* imout, size_t windowSize,
                   size_t step);

}

#endif    /* MISC_H*/

