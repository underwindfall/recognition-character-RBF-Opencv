#ifndef S2PROCESSORIGINAL_H
#define S2PROCESSORIGINAL_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include "S2ProcessStrategy.h"

namespace gst
{

class S2ProcessOriginal : public S2ProcessStrategy
{

public:

    DLLEXP virtual void process(const std::vector<std::vector<cv::Mat> >& c1,
                                const std::vector<std::vector<cv::Mat>>& patches,
                                std::vector<float>* out)
                                const;

    DLLEXP virtual long getId() const { return ID; }

    static const long ID = 20150326;

};

}

#endif /* S2PROCESSORIGINAL_H*/
