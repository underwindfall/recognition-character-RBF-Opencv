#ifndef S2PROCESSSTRATEGY_H
#define S2PROCESSSTRATEGY_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include <vector>
#include <opencv2/opencv.hpp>

namespace gst
{

class S2ProcessStrategy
{

public :

    DLLEXP virtual ~S2ProcessStrategy() {}

    DLLEXP virtual void process(const std::vector<std::vector<cv::Mat>>& c1,
                                const std::vector<std::vector<cv::Mat>>& patches,
                                std::vector<float>* out)
                                const = 0;

    DLLEXP virtual long getId() const = 0;

};

}

#endif /* S2PROCESSSTRATEGY*/
