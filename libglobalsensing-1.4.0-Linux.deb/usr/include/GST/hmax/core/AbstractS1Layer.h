/*
* File:   AbstractS1Layer.h
* Author: olivier
*
* Created on 11 february 2015, 15:12
*/

#ifndef ABSTRACTS1LAYER_H
#define ABSTRACTS1LAYER_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include <opencv2/core/core.hpp>
#include <vector>
#include "GST/core/Readable.h"
#include "GST/core/Writable.h"

namespace gst
{


/**
* Abstract class for S1 layer.
*/
class AbstractS1Layer : public Readable, public Writable
{

public:

    /**
    * Interface for clone() methods.
    *
    * This method is pure virtual, and as such must be implemented
    * by the subclasses. If the copy constructor of a subclass called ABSTRACTS2C2LAYER_H
    * is implemented, the implementation of clone() is:
    * return new A(*this);
    *
    * This pure virtual method follows the "virtual constructor" pattern.
    */
    DLLEXP virtual AbstractS1Layer* clone() const = 0;

    /**
    * Destructor.
    */
    DLLEXP virtual ~AbstractS1Layer() {}

    /**
    * Process input image.
    *
    * This function provides a generic interface to the class user, allowing
    * to extract S1 transform of an input image. It is pure virtual, and must
    * be implemented by subclass.
    *
    * out is a 2D vector. The first dimension corresponds to the orientation,
    * and the second one to the scale. Thus, out[i][j] should give the output
    * of the Gabor filter with the i-th orientation and j-scale. This is
    * important, as C1 layer classes expect data to be formatted as such.
    *
    * @param im input image
    * @param out output images.
    */
    DLLEXP virtual void process(const cv::Mat im,
                                std::vector<std::vector<cv::Mat> >* out)
                                const
                                = 0;


};

}

#endif /* ABSTRACTS1LAYER_H*/
