/*
* File:   AbstractC1Layer.h
* Author: olivier
*
* Created on 11 february 2015, 15:12
*/

#ifndef ABSTRACTC1LAYER_H
#define ABSTRACTC1LAYER_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include <opencv2/core/core.hpp>
#include <vector>
#include "GST/core/Readable.h"
#include "GST/core/Writable.h"

namespace gst
{

/**
* Abstract class for S1 layer.
*/
class AbstractC1Layer : public Readable, public Writable
{

public:

    /**
    * Interface for clone() methods.
    *
    * This method is pure virtual, and as such must be implemented
    * by the subclasses. If the copy constructor of a subclass called ABSTRACTS2C2LAYER_H
    * is implemented, the implementation of clone() is:
    * return new A(*this);
    *
    * This pure virtual method follows the "virtual constructor" pattern.
    */
    DLLEXP virtual AbstractC1Layer* clone() const = 0;

    /**
    * Destructor.
    */
    DLLEXP virtual ~AbstractC1Layer() {}

    /**
    * Apply C1 process to input S1 images.
    *
    * This function provides a generic interface to the class user, allowing
    * to extract C1 transform of an input image in S1 space. It is pure virtual,
    * and must be implemented by subclass.
    *
    * The S1 patches are given by the s1 parameter, which is a 2D vector of
    * cv::Mat object. The first dimension corresponds to the orientation of
    * the filter, and the second dimension corresponds to the scale. The
    * the input image in S1 space must all be 2D (i.e, they must have only one
    * channel).
    *
    * The results are written in the output 2D vector. Like the input vector,
    * its first dimension corresponds to the orientation of the filter, and the
    * second dimension corresponds to the scale. All C1 images are represented
    * as Mat objects having one channel, of type double (i.e CV_64F in OpenCV
    * type set). If the output vector wasn't empty, the results are just
    * appended to it.
    *
    * @param s1 image in S1 representation
    * @param out pointer to output vector
    */
    DLLEXP virtual void process(const std::vector<std::vector<cv::Mat> >& s1,
                                std::vector<std::vector<cv::Mat> >* out)
                                const
                                = 0;
};

}

#endif /* ABSTRACTC1LAYER_H*/
