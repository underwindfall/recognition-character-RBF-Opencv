#ifndef S2RANDOMTRAINER_H
#define S2RANDOMTRAINER_H

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

#include "S2TrainerStrategy.h"

namespace gst
{

class S2RandomTrainer : public S2TrainerStrategy
{

public:

    DLLEXP S2RandomTrainer();

    DLLEXP S2RandomTrainer(const std::map<size_t, size_t>& pSizes) : pSizes(pSizes) {}

    DLLEXP void train(const std::vector<std::vector<std::vector<cv::Mat>>>& c1, std::vector<std::vector<cv::Mat>>*out);

    static const long ID = 20150326;

    DLLEXP virtual long getId() const { return ID; }


private:

    std::map<size_t, size_t> pSizes;

};

}

#endif /* S2RANDOMTRAINER_H*/
