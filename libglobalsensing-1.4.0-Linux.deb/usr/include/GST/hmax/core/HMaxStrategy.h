/*
* File:   HMaxStrategy.h
* Author: olivier
*
* Created on 11 february 2015, 15:12
*/

#ifndef HMAXSTRATEGY_H
#define HMAXSTRATEGY_H

#include "GST/hmax/core/AbstractS1Layer.h"
#include "GST/hmax/core/AbstractC1Layer.h"
#include "GST/hmax/S2C2Layers.h"
#include "GST/core/Writable.h"

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{

/**
* Generic class for all HMAX implementations.
*
* This class abstracts the HMAX model, whatever its precise implementation.
* It has 3 member: s1, which represents a S1 layer implementation; c1, which
* represents a C1 layer implementation; and s2C2, which represents the combined
* implementation of a S2 layer and a C2 layer. Those member are of abstract types,
* which do not provide the processes themselves but leave them to their subclasses.
* Thus, this class follows the Strategy design pattern.
*
* None of this class constructor should be called directly, unless the user know what
* he's doing - for instance, when he wants to use a home-made HMAX implementation.
* Instead, either use one of its subtypes' constructor, or read an HMaxStrategy instance
* from a stream with the HMaxLoader class.
*
* @see HMaxLoader
*/
class HMaxStrategy : public Writable
{

public:

    /**
    * Default constructor.
    *
    * Set all attribute to nullptr.
    *
    * None of this class' constructors should be called directly.
    */
    DLLEXP HMaxStrategy();

    /**
    * Constructor.
    *
    * Copy the given pointers to the newly created object's members.
    * One must make sure to instantiate the parameters with "new", in order
    * to make sure the objects are not destroyed when they go out of scope.
    * One must not take care of memory de-allocation, as it is performed
    * in ~HMax>Strategy().
    *
    * None of this class' constructors should be called directly.
    *
    * @param s1 S1 layer
    * @param c1 C1 layer
    * @param s2C2 S2 and C2 layers
    */
    DLLEXP HMaxStrategy(AbstractS1Layer* s1, AbstractC1Layer* c1, S2C2Layers* s2C2);

    /**
    * Copy constructor.
    *
    * This constructor produces a deep copy of a HMaxStrategy object.
    * The members of the resulting HMaxStrategy instance are of the same
    * subtypes as the original object's members.
    *
    * None of this class' constructors should be called directly.
    *
    * @param orig original instance to copy
    */
    DLLEXP HMaxStrategy(const HMaxStrategy& orig) : s1(orig.s1->clone()), c1(orig.c1->clone()), s2C2(new S2C2Layers(*orig.s2C2)) {}

    /**
    * Assignment operator overload.
    *
    * This method produces a deep copy of a HMaxStrategy object.
    * The members of the resulting HMaxStrategy instance are of the same
    * subtypes as the original object's members.
    *
    * @param orig original instance to copy
    */
    DLLEXP HMaxStrategy& operator=(const HMaxStrategy& orig);

    /**
    * Destructor.
    */
    DLLEXP virtual ~HMaxStrategy();

    /**
    * Train s2 layer of HMax object.
    *
    * For more information about the pSizes parameters, see S2C2Layers::train()
    * documentation.
    *
    * @param im input image, in grayscale space
    * @param pSizes sizes of the patchs to crop.
    * @see S2C2Layers::train()
    */
    DLLEXP virtual void train(const std::vector<cv::Mat>& im);

    /**
    * Apply S1 and C2 layers' processes to input image.
    *
    * The input image must be of the type processed by the different layers.
    *
    * @param im input image, as grayscale
    * @param out pointer to vector of vectors where to write the results
    */
    DLLEXP virtual void s1c1(const cv::Mat& im, std::vector<std::vector<cv::Mat> >* out) const;

    /**
    * Performs the whole HMax process to input image.
    *
    * The object must have been trained first with the train() method.
    *
    * The input image must be the type processed by the different layers.
    *
    * @param im input image
    * @param out pointer to output vector
    */
    DLLEXP virtual void s1c1s2c2(const cv::Mat& im, std::vector<float>* out) const;

    /**
    * Check whether the object has been trained.
    *
    * This function is only a shortcut for getS2C2().isTrained().
    *
    * @return true if trained, false otherwise.
    */
    DLLEXP virtual bool isTrained() const;

    /**
    * Get number of learnt patches in S2 layers.
    *
    * @return getS2C2().getNbPatches()
    */
    DLLEXP virtual size_t getOutputVectorSize() const;

    /**
    * Write HMaxStrategy instance to output stream.
    *
    * This methods writes the data contained by this class instance,
    * by calling its members' write() methods.
    *
    * @param os output stream to copy
    */
    DLLEXP virtual void write(std::ostream& os) const;

    /**
    * Write HMaxStrategy instance to file.
    *
    * Opens the file at the given path, writes data with the "stream"
    * overload of write(), then closes the file.
    *
    * @param path path to output file.
    */
    DLLEXP virtual void write(const std::string& path) const { Writable::write(path); }

    /**
    * s1 member setter.
    *
    * This method is needed by the HMaxLoader class. It should not
    * be used directly by the user.
    *
    * @param s1 new value for s1 member.
    */
    DLLEXP virtual void setS1(AbstractS1Layer* s1);

    /**
    * c1 member setter.
    *
    * This method is needed by the HMaxLoader class. It should not
    * be used directly by the user.
    *
    * @param c1 new value for c1 member.
    */
    DLLEXP virtual void setC1(AbstractC1Layer* c1);

    /**
    * s2C2 member setter.
    *
    * This method is needed by the HMaxLoader class. It should not
    * be used directly by the user.
    *
    * @param s2C2 new value for s2C2 member.
    */
    DLLEXP virtual void setS2C2(S2C2Layers* s2C2);

    DLLEXP void exportS2PatchesAsImages(const std::string& prefix) const { s2C2->exportPatchesAsImages(prefix); }

    DLLEXP void writeS2C2(const std::string& path) const { s2C2->Writable::write(path); }


protected:

    /**
    * S1 layer.
    */
    AbstractS1Layer* s1;

    /**
    * C1 layer.
    */
    AbstractC1Layer* c1;

    /**
    * S2 and C2 layers.
    */
    S2C2Layers* s2C2;

};

}

#endif /* HMAXSTRATEGY_H*/
