/*
* File:   C1Layer.h
* Author: olivier
*
* Created on 22 octobre 2014, 23:18
*/

#ifndef C1LAYER_H
#define    C1LAYER_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#define C1LAYER_ORIGINAL 20140128

#include <vector>
#include <opencv2/core/core.hpp>
#include <ostream>
#include <istream>
#include "GST/hmax/core/AbstractC1Layer.h"

namespace gst
{

/**
* HMax C1 layer.
*
* This class provides the needed features to perform the C1 HMAX layer
* process on images in S1 spaces (see S1 class).
*
* To use it, one first needs to instantiate it. The easiest way to do that is
* to call the default constructor, which will create a C1Layer objects with
* default parameters, as given in the original HMAX paper ("Robust object
* recognition with cortex-like mechanisms", Serre et al.). One may also use
* the other constructor in order to use custom parameters. Once an object has
* been created, one can use the process() method to perform the C1 layer
* process.
*/
class C1Layer : public AbstractC1Layer
{
public:

    /**
    * Default constructor.
    *
    * Creates a C1 layer object with default parameters as given in original
    * HMAX paper.
    */
    DLLEXP C1Layer();

    /**
    * Constructor.
    *
    * This constructor allows one to use custom parameters for the C1 layer.
    *
    * nbLayerPooling is the amount of windows accross which this layer performs the max operation.
    * poolingWindowSizes contains the different pooling window sizes, for each layer. The
    * i-th element will be used for the images in the scales of indexes
    * {nlp*i, ..., nlp*(i+1)-1} in S1 space. steps contains the steps between
    * two pooling windows during the max operation; as poolingWindowSizes, the i-th element
    * will be use for the images in the scales of indexes
    * {i*nlp, ..., i*(nlp+1)-1} in S1 space. steps and pws must have the same
    * size.
    *
    * Calling the default constructor is equivalent to C1Layer(2, pws, steps),
    * where pws contains {8, 10, 12, 14, 16, 18, 20, 22} and steps contains
    * {4, 5, 6, 7, 8, 9, 10, 11}.
    *
    * @param nbLayerPooling number of windows accross which to pool for the max operation
    * @param poolingWindowSizes pooling window sizes
    * @param steps step between two pooling windows
    */
    DLLEXP C1Layer(size_t nbLayerPooling, const std::vector<size_t>& poolingWindowSizes,
                   const std::vector<size_t>& steps);

    /**
    * Constructor.
    *
    * Construct object with data from stream.
    *
    * @param is input stream to read
    */
    DLLEXP C1Layer(std::istream& is);

    /**
    * Create a deep copy of a C1Layer instance.
    *
    * @return a pointer to a deep copy of a C1Layer instance.
    */
    DLLEXP virtual AbstractC1Layer* clone() const { return new C1Layer(*this); }

    /**
    * Destructor.
    */
    DLLEXP virtual ~C1Layer() {}

    /**
    * Apply C1 process to input S1 images.
    *
    * This function applies the process of the C1 layer to the input image in
    * S1 representation.
    *
    * The S1 patches are given by the s1 parameter, which is a 2D vector of
    * cv::Mat object. The first dimension corresponds to the orientation of
    * the filter, and the second dimension corresponds to the scale. The
    * the input image in S1 space must all be 2D (i.e, they must have only one
    * channel).
    *
    * The results are written in the output 2D vector. Like the input vector,
    * its first dimension corresponds to the orientation of the filter, and the
    * second dimension corresponds to the scale. All C1 images are represented
    * as Mat objects having one channel, of type double (i.e CV_64F in OpenCV
    * type set). If the output vector wasn't empty, the results are just
    * appended to it.
    *
    * @param s1 image in S1 representation
    * @param out pointer to output vector
    */
    DLLEXP void process(const std::vector<std::vector<cv::Mat> >& s1,
                 std::vector<std::vector<cv::Mat> >* out) const;

    /**
    * Write C1 layer parameters to stream.
    *
    * @param os stream where to write data
    */
    DLLEXP void write(std::ostream& os) const;

    /**
    * Read C1 layer parameters from stream.
    *
    * We assume that we read from a file containing the right C1Layer
    * sub-type.
    *
    * @param is stream from where to read data
    */
    DLLEXP void read(std::istream& is);

    /**
    * Create C1Layer instance with parameters read from input stream.
    *
    * This method is used by the HMaxLoader class, and should not be called directly.
    *
    * @param version id of the C1Layer object to read from stream.
    * @return a pointer to the newly created instance
    */
    DLLEXP static AbstractC1Layer* load(long version, std::istream& is) { return new C1Layer(is); }


private:

    /**
    * Max pooling windows' sizes.
    */
    std::vector<size_t> poolingWindowSizes;

    /**
    * Distance in pixels between two consecutive pooling windows.
    */
    std::vector<size_t> steps;

    /**
    * Number of layer accross which the max pooling is performed.
    */
    size_t nbLayerPooling;

};

}

#endif    /* C1LAYER_H*/

