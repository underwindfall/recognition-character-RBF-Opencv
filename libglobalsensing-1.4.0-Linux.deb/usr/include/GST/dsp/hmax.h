#ifndef HMAX_H
#define HMAX_H

#include <stddef.h>
#include <stdlib.h>
#include "imfilter.h"
#include "mycomplex.h"

#define HMAX_S1_NSCALES    16 /* number of different scales in S1*/
#define HMAX_S1_NORIENT     4 /* number of different orientations in S1*/
#define HMAX_S1_GAMMA    0.3f /* Gabor filters aspect ratio in S1' gabor filters*/

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus*/

    typedef struct
    {
        size_t w, /* filter side*/
            s; /* step*/
    } maxfilter_t;

    /* Create filter bank used in HMAX S1 layer
    *
    * See "Robust object recognition with Cortex-like mechanism",
    * Serre et al., 2007
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - dst must be preallocated
    *
    * @param dst pointer to buffer where to write output
    * @return number of filters in filter bank
    */
    DLLEXP size_t hmax_create_filter_bank(fmatf_t*dst);

    /* Create filter bank used in HMAX S1 layer in Fourier domain
    *
    * Same as hmax_create_filter_bank(), except that if performs
    * a Fourier transform afterwards. To do it, it padds the kernels
    * with zeros so that the output kernel is of size (w, h) in Fourier
    * domain. w and h must be choosen so that the kernel has the same
    * dimensions than the images it shall be applied to.
    *
    * Tested requirements:
    *  - w >= 37
    *  - h >= 37
    *  - w must be a power of two
    *  - h must be a power of two
    *
    * Untested requirements:
    *  - dst must be preallocated
    *
    * @param w output kernel width in Fourier domain
    * @param h output kernel height in Fourier domain
    * @param dst pointer to buffer where to write output
    * @return number of filters in filter bank, or -1 if error
    */
    DLLEXP int hmax_create_filter_bank_fourier(size_t w,
                                               size_t h,
                                               cmatf_t*dst);

    /* Apply HMAX C1 layer to set of images
    *
    * See "Robust object recognition with Cortex-like mechanism",
    * Serre et al., 2007
    *
    * Tested requirements:
    *  - nscales >= n_merge_scales
    *  - nscales % n_merge_scales != 0
    *  - all images in src must have the same width and height
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - params must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer to first element of input array
    * @param params pointer to first element of parameters array
    * @param nori number of orientations in S1 filter bank
    * @param nscales number of scales in S1 filter bank
    * @param n_merge_scales number of scales to merge
    * @param dst pointer to buffer where to write output
    * @return 0 if fine, -1 otherwise
    */
    DLLEXP int c1(fmatf_t*src, maxfilter_t*params, size_t nori,
                  size_t nscales, size_t n_merge_scales, fmatf_t*dst);

    /* Convert array of matrices of float into a single array.
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer fo first element of arrays of input matrices
    * @param n number of elements in src array
    * @param dst pointer to buffer where to write output
    * @return number of elements in newly created array
    */
    DLLEXP size_t fmats2arrayf(fmatf_t*src, size_t n, float*dst);

#ifdef __cplusplus
}
#endif  /* __cplusplus*/

#endif /* HMAX_H*/
