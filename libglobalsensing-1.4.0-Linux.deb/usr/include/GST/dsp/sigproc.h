#ifndef SIGPROC_H
#define SIGPROC_H

#include <complex.h>
#include <stdlib.h>
#include "mycomplex.h"

#define IS_POWER_OF_2(x) ((x != 0) && !(x & (x - 1)))

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus*/

    /* Compute DFT out-of-place by a radix-2 DIT FFT on real value data.
    *
    * This function should not be used directly. See ffftf(). and cfftf().
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer to first element of input array
    * @param N number of elements in array
    * @param s index factor
    * @param osrc offset for src array
    * @param odst offst for dst arrat
    * @param dst pointer to buffer where to write output
    */
    DLLEXP void fditfftf_radix2(float*src, size_t N, size_t s, fcomplex*dst);

    /* Compute DFT out-of-place by a radix-2 DIT FFT on complex value data.
    *
    * This function should not be used directly. See ffftf(). and cfftf().
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer to first element of input array
    * @param N number of elements in array
    * @param s index factor
    * @param dst pointer to buffer where to write output
    */
    DLLEXP void cditfftf_radix2(fcomplex*src, size_t N, size_t s, fcomplex*dst);

    /* Compute FFT on single precision floating point real data.
    *
    * Implement the FFT as described there:
    * http://cnx.org/contents/ba55ed41-b37b-45bd-89c9-e6b67725401e@15/Implementing-FFTs-in-Practice
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer to first element of input array
    * @param log2N log2 of the number of elements in array
    * @param dst pointer to buffer where to write output
    */
    DLLEXP void ffftf_radix2(float*src, size_t log2N, fcomplex*dst);

    /* Compute FFT on single precision floating point complex data.
    *
    * Implement the FFT as described there:
    * http://cnx.org/contents/ba55ed41-b37b-45bd-89c9-e6b67725401e@15/Implementing-FFTs-in-Practice
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer to first element of input array
    * @param log2N log2 of the number of elements in array
    * @param dst pointer to buffer where to write output
    */
    DLLEXP void cfftf_radix2(fcomplex*src, size_t log2N, fcomplex*dst);

    /* Compute inverse DFT out-of-place by a radix-2 DIT FFT on complex value data.
    *
    * This function should not be used directly. See ffftf(). and cfftf().
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer to first element of input array
    * @param N number of elements in array
    * @param s index factor
    * @param dst pointer to buffer where to write output
    */
    DLLEXP void ciditfftf_radix2(fcomplex*src, size_t N, size_t s, fcomplex*dst);

    /* Compute inverse FFT on single precision floating point complex data.
    *
    * Implement the FFT as described there:
    * http://cnx.org/contents/ba55ed41-b37b-45bd-89c9-e6b67725401e@15/Implementing-FFTs-in-Practice
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  - src must be contiguous in memory
    *  - dst must be preallocated
    *
    * @param src pointer to first element of input array
    * @param log2N log2 of the number of elements in array
    * @param dst pointer to buffer where to write output
    */
    DLLEXP void cifftf_radix2(fcomplex*src, size_t log2N, fcomplex*dst);

    /* Add two complex numbers coded with single precision.
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  None
    *
    * @param a first operand
    * @param b second operand
    * @return addition result
    */
    DLLEXP fcomplex caddf(fcomplex a, fcomplex b);

    /* Subtract two complex numbers coded with single precision.
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  None
    *
    * @param a first operand
    * @param b second operand
    * @return addition result
    */
    DLLEXP fcomplex csubf(fcomplex a, fcomplex b);

    /* Multiply two complex numbers coded with single precision.
    *
    * This function should not be necessary. Let's try to get rid of it when
    * passing everything to C.
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  None
    *
    * @param a first operand
    * @param b second operand
    * @return addition result
    */
    DLLEXP fcomplex cmulf(fcomplex a, fcomplex b);

    /* Multiply a complex number with a real one
    *
    * This function should not be necessary. Let's try to get rid of it when
    * passing everything to C.
    *
    * Tested requirements:
    *  None
    *
    * Untested requirements:
    *  None
    *
    * @param a complex operand
    * @param b real operand
    * @return addition result
    */
    DLLEXP fcomplex fmulf(fcomplex a, float b);


#ifdef __cplusplus
}
#endif  /* __cplusplus*/

#endif /* SIGPROC_H*/
