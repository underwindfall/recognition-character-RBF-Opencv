#ifndef IMFILTER_H
#define IMFILTER_H

#include <complex.h>
#include <stdlib.h>
#include "mycomplex.h"

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

    typedef struct
    {
        float *data; /* raw data */
        size_t r, /* number of rows (height) */
            c; /* number of columns (width) */
    } fmatf_t;

    typedef struct
    {
        fcomplex *data; /* raw data */
        size_t r, /* number of rows (height) */
            c; /* number of columns (width) */
    } cmatf_t;

    /* Perform 2D convolution on single precision floating point data.
     *
     * Only valid part of the convolution is going to be computed. Therefore
     * the output image dimensions shall be:
     * (wsrc-wp-wk+1) x (hsrc-hp-hk+1).
     *
     * The filtering operation is performed as a correlation, not a true
     * convolution. Thus, one must make sure that the kernel is revert.
     *
     * Tested requirements:
     *  None
     *
     * Untested requirements:
     *  - input image must be stored line-wise in a contiguous manner in memory
     *  - kernel must be stored line-wise in a contiguous manner in memory
     *  - dst must be preallocated
     *  - wdst must be preallocated
     *  - hdst must be preallocated
     *
     * @param src   pointer to input image's first pixel
     * @param wsrc  input image width
     * @param hsrc  input image height
     * @param wp    input image padding to top and bottom borders
     * @param hp    input image padding to left and right borders
     * @param k     pointer to kernel's first coefficient
     * @param kw    kernel width
     * @param kh    kernel height
     * @param dst   pointer to buffer where to write output
     * @param wdst  pointer to where to write output image's width
     * @param hdst  pointer to where to write output image's height
     * @return 0 if fine, -1 otherwise (see "Requirements")
     */
    DLLEXP void fconv2f(float  *src, size_t wsrc, size_t hsrc, size_t wp, size_t hp, float *k,
                        size_t wk, size_t hk, float *dst, size_t *wdst, size_t *hdst);

    /* Compute 2D FFT radix-2 on single precision floating point real data.
     *
     * This function first computes ffts, row by row, using ffftf().
     *
     * Tested requirements:
     *  None
     *
     * Untested requirements:
     *  - src must be contiguous in memory
     *  - image pixels must be stored row by row
     *  - dst must be preallocated
     *
     * @param src pointer to first element of input 2D array
     * @param log2W log2 of the image width
     * @param log2H log2 of the image height
     * @param dst pointer to buffer where to write output
     * @see ffftf
     */
    DLLEXP void ffft2f_radix2(float  *src, size_t log2W, size_t log2H, fcomplex  *dst);

    /* Compute inverse 2D FFT radix-2 on single precision floating point real data.
     *
     * This function first computes ffts, row by row, using ffftf().
     *
     * Tested requirements:
     *  None
     *
     * Untested requirements:
     *  - src must be contiguous in memory
     *  - image pixels must be stored row by row
     *  - dst must be preallocated
     *
     * @param src pointer to first element of input 2D array
     * @param log2W log2 of the image width
     * @param log2H log2 of the image height
     * @param dst pointer to buffer where to write output
     * @see ffftf
     */
    DLLEXP void fifft2f_radix2(fcomplex  *src, size_t log2W, size_t log2H, fcomplex  *dst);

    /* Subsample image with local maxima.
     *
     * Tested requirements:
     *  None
     *
     * Untested requirements:
     *  - input image must be stored line-wise in a contiguous manner in memory
     *
     * @param src   pointer to input image's first pixel
     * @param wsrc  input image width
     * @param hsrc  input image height
     * @param wf    neighboring window's width
     * @param hf    neighboring window's height
     * @param sx    step between two neighboring windows along the x-axis
     * @param sy    step between two neighboring windows along the y-axis
     * @param dst   pointer to buffer where to write output
     * @param wdst  pointer to where to write output image's width
     * @param hdst  pointer to where to write output image's height
     * @return 0 if fine, -1 otherwise (see "Requirements")
     */
    DLLEXP void fmaxfilt2f(float  *src, size_t wsrc, size_t hsrc, size_t wf, size_t wh, size_t sx,
                           size_t sy, float  *dst, size_t  *wdst, size_t  *hdst);

    /* Transpose matrix of arbitrary elements.
     *
     * Tested requirements:
     *  None
     *
     * Untested requirements:
     *  - src must be contiguous in memory
     *  - dst must be preallocated
     *
     * @param src pointer to input matrix's first element
     * @param r number of rows in matrix
     * @param c number of cols in matrix
     * @param wl size of elements to transpose, e.g sizeof(float)
     * @param dst pointer to buffer where to write output
     */
    DLLEXP void transpose(void  *src, size_t r, size_t c, size_t wl, void  *dst);

    /* Create real 2D Gabor filter kernel.
     *
     * This function produces a Gabor filter kernel with real values.
     *
     * The resulting kernel is intended to be used with the convolution functions
     * provided in this library - thus its coefficients are stored in reverse
     * order.
     *
     * Tested requirements:
     *  - s must be odd
     *  - sigma > 0
     *  - lambda > 0
     *  - gamma > 0
     *
     * Untested requirements:
     *  - dst must be pre-allocated
     *  - theta must be expressed in radians
     *
     * @param sigma Gaussian standard deviation
     * @param lambda cosine wavelength
     * @param gamma aspect ratio
     * @param theta orientation in radians
     * @param s output kernel size
     * @param dst pointer to buffer where to write output
     * @return 0 if fine, -1 otherwise (see "Tested requirements")
     */
    DLLEXP int fgabork2f(float sigma, float lambda, float gamma, float theta, size_t s,
                         float  *dst);

    /* Apply bank of linear filter to input image.
     *
     * Tested requirements:
     *  - all filters' kernels must have odd width and heights
     *
     * Untested requirements:
     *  - src must be contiguous in memory
     *  - filter_bank must be contiguous in memory
     *  - dst must be preallocated
     *
     * @param src pointer to input matrix
     * @param filter_bank pointer to filter array's first element
     * @param nfilters number of filters in filter_bank array
     * @param dst pointer to buffer where to write output
     * @return 0 if fine, -1 otherwise
     */
    DLLEXP int apply_filterbank(fmatf_t  *src, fmatf_t  *filter_bank, size_t nfilters, fmatf_t  *dst);

    /* Shift data so that a proper image is made after an FFT and a IFFT.
     *
     * This function splits the input image in four squares: A (top left),
     * B (top right), C (bottom left) and D (bottom right). The squares
     * are shifted so that the output image is given by: D (top left),
     * C (top right), B (bottom left) and A (bottom right).
     *
     * Tested requirements:
     *  - w % 2 == 0
     *  - h % 2 == 0
     *
     * Untested requirements:
     *  - src must be contiguous in memory
     *  - dst must be preallocated
     *
     * @param src pointer to input matrix
     * @param w matrix width
     * @param h matrix height
     * @param wl elements size in bytes, eg sizeof(float)
     * @param dst destination array
     * @return 0 if fine, -1 if error
     */
    DLLEXP int fftfshift2(void  *src, size_t w, size_t h, size_t wl,
                          void  *dst);

    /* Apply bank of linear filter to input image in Fourier domain.
     *
     * First of all, this function performs a 2D-FFT on the input image.
     * Then, it applies all filters in the filter bank to in transformed image.
     * Finally, all filtered images are transformed back to the spatial domain.
     *
     * Tested requirements:
     *  - all filters must be of the same size of the input image
     *  - src->r must be a power of 2
     *  - src->c must be a power of 2
     *  - dst must be preallocated
     *
     * Untested requirements:
     *  - src must be contiguous in memory
     *  - filter_bank must be contiguous in memory
     *  - dst must be preallocated
     *
     * @param src pointer to input matrix
     * @param filter_bank pointer to filter array's first element
     * @param nfilters number of filters in filter_bank array
     * @param dst pointer to buffer where to write output
     * @return 0 if fine, -1 otherwise
     */
    DLLEXP int apply_filterbank_fourier(fmatf_t  *src, cmatf_t  *filter_bank,
                                        size_t nfilters, fmatf_t  *dst);

    /* Padd array with value.
     *
     * Tested requirements:
     *  None
     *
     * Untested requirements:
     *  - dst->data must be preallocated
     *
     * @param src pointer to source matrix
     * @param l number of lines to add on the left of the input matrix
     * @param r number of lines to add on the right of the input matrix
     * @param u number of lines to add on top of the matrix
     * @param d number of lines to add on the bottom of the matrix
     * @param v value to set to appended elements
     * @param dst destination matrix
     */
    DLLEXP void fpaddingf(fmatf_t  *src, size_t l, size_t r, size_t u, size_t d,
                          float v, fmatf_t  *dst);

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* IMFILTER_H */
