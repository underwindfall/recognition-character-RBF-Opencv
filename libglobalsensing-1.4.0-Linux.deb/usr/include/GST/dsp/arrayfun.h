#ifndef ARRAYFUN_H
#define ARRAYFUN_H

#include <complex.h>
#include <stdlib.h>
#include <stddef.h>
#include "mycomplex.h"

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

/* Apply function to all elements of array.
 *
 * Operates on single precision floating point elements.
 *
 * Tested requirements:
 *  None
 *
 * Untested requirements:
 *  - dst must be preallocated
 *
 * @param f pointer the function to apply
 * @param src source array
 * @param dst destination buffer
 * @param s number of elements in array
 * @return 0 if no error, -1 otherwise (see "Tested requirements")
 */
DLLEXP void farrayfunf(float( *f)(float), float *src, float *dst, size_t s);

/* Apply function by taking operands from two real arrays, element by element
 *
 * Operates on single precision floating point elements.
 *
 * Tested requirements:
 *  None
 *
 * Untested requirements:
 *  - src1 must be contiguous in memory
 *  - src2 must be contiguous in memory
 *  - dst must be preallocated
 *
 * @param f pointer the function to apply
 * @param src1 first source array
 * @param src2 second source array
 * @param dst destination buffer
 * @param s number of elements in array
 * @return 0 if no error, -1 otherwise (see "Tested requirements")
 */
DLLEXP void ffarrayfunf(float( *f)(float, float), float *src1, float *src2,
                    float *dst, size_t s);

/* Apply function by taking operands from two complex arrays, element by element
 *
 * Operates on single precision floating point elements.
 *
 * Tested requirements:
 *  None
 *
 * Untested requirements:
 *  - src1 must be contiguous in memory
 *  - src2 must be contiguous in memory
 *  - dst must be preallocated
 *
 * @param f pointer the function to apply
 * @param src1 first source array
 * @param src2 second source array
 * @param dst destination buffer
 * @param s number of elements in array
 */
DLLEXP void ccarrayfunf(fcomplex( *f)(fcomplex, fcomplex), fcomplex *src1, fcomplex *src2,
                        fcomplex *dst, size_t s);

/* Get real part of complex elements in input array.
 *
 * Tested requirements:
 *  - None
 *
 * Untested requirements:
 *  - src must be contiguous in memory
 *  - dst must be preallocated
 *
 * @param src pointer to first element in input array
 * @param n number of elements in array
 * @param dst pointer to buffer where to write output
 */
DLLEXP void frealf(fcomplex * src, size_t n, float *dst);

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* ARRAYFUN_H */
