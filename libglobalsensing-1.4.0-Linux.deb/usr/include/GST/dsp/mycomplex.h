#ifndef MYCOMPLEX_H
#define MYCOMPLEX_H

#if __STDC_VERSION__ >= 199901L
#ifndef C99
#define C99
#endif
#endif

#ifdef C99
//#include <complex.h>
typedef float __complex__ fcomplex;
#else
typedef _Fcomplex fcomplex;
#endif

#endif /* MYCOMPLEX_H*/

