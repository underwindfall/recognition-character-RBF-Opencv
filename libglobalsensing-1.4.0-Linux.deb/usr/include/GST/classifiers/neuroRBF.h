/*
* File:   neuroRBF.h
* Author: Olivier
*
* Created on 30 octobre 2012, 18:17
*/

#ifndef neuroRBF_H
#define    neuroRBF_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cassert>
#include <functional>
#include <algorithm>
#include <numeric>
#include <climits>
#include <cfloat>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "neuroRBFCat.h"

#include <GST/core/gst.h>

#include <armadillo>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

using namespace std;

namespace gst
{
    class neuroRBF {
    public:
        DLLEXP neuroRBF();                        ///< Creates a default and empty neuroRBF.
        DLLEXP neuroRBF(const neuroRBF& orig);    ///< Creates a neuroRBF by copying an other neuroRBF provided as a parameter.
        DLLEXP virtual ~neuroRBF();                ///< Destructor for objects of the neuroRBF class.
        DLLEXP neuroRBF &operator=(const neuroRBF &orig); ///< Affectation operator to allow copy of a neuroRBF to an other.

        DLLEXP int getnumCat() const;                    ///< Returns the number of category as a constant.
        DLLEXP unsigned int getvSize() const;            ///< Returns the size of vectors to be classified as a constant.
        DLLEXP unsigned int getnumCenters() const;        ///< Returns the number of centers that compose the learning base as a constant.
        DLLEXP float getmu() const;                        ///< Returns the distance splitting parameter as a constant.
        DLLEXP int getmode() const;                        ///< Returns the mode parameter as a constant.
        DLLEXP vector<neuroRBFCat> getnetCat() const;    ///< Returns the list of categories as a constant.
        DLLEXP neuroRBFCat getnetCat(int catID) const;        ///< Returns the cat th element of network categories as a constant.
        DLLEXP neuroRBFCat* getpnetCat(int catID) const;    ///<  Returns a pointer on the cat th element of network categories as a constant.
        DLLEXP int getnetCatColor(int catID) const;        ///< Returns the colour of the categories of the category with ID catID as a constant.
        DLLEXP string getnetCatLabel(int catID) const;    ///< Returns the colour of the categories of the category with ID catID as a constant.
        DLLEXP int getvWidth() const;                    ///< Returns the original size of the data ROI in the y dimension as a constant.
        DLLEXP int getvHeight() const;                    ///< Returns the original size of the data ROI in the y dimension as a constant.
        DLLEXP bool getresizeFlag() const;                ///< Returns the resizeFlag used in the network context as a constant.

        DLLEXP int getnumCat();                        ///< Returns the number of category.
        DLLEXP unsigned int getvSize();                ///< Returns the size of vectors to be classified.
        DLLEXP unsigned int getnumCenters();        ///< Returns the number of centers that compose the learning base.
        DLLEXP float getmu();                        ///< Returns the distance splitting parameter.
        DLLEXP int getmode();                        ///< Returns the mode parameter.
        DLLEXP vector<neuroRBFCat> getnetCat();    ///< Returns the list of categories.
        DLLEXP neuroRBFCat getnetCat(int catID);        ///< Returns the cat th element of network categories.
        DLLEXP neuroRBFCat* getpnetCat(int catID);        ///< Returns a pointer on the cat th element of network categories.
        DLLEXP int getnetCatColor(int catID);        ///< Returns the colour of the category with ID catID.
        DLLEXP string getnetCatLabel(int catID);    ///< Returns the label of the category with ID catID.
        DLLEXP bool getnetCatCenter(int catID, int centerID, vector<int>& center); ///< Returns the center with ID centerID from the category with ID catID.
        DLLEXP int getvWidth();                    ///< Returns the original size of the data ROI in the x dimension.
        DLLEXP int getvHeight();                ///< Returns the original size of the data ROI in the y dimension.
        DLLEXP bool getresizeFlag();                ///< Returns the resizeFlag used in the network context.

        DLLEXP int setnumCat();                            ///< Sets the number of category in the neuroRBF automatically by computing the good value.
        DLLEXP int setnumCat(int nCat);                    ///< Sets the number of category in the neuroRBF. This function should not be used except expert users.
        DLLEXP unsigned int setvSize();                    ///< Sets the size of vectors that will be categorizes in the neuroRBF automatically by computing the good value.
        DLLEXP unsigned int setvSize(unsigned int size);    ///< Sets the size of vectors that will be categorizes in the neuroRBF. This function should not be used except by expert users.
        DLLEXP unsigned int setnumCenters();                        ///< Sets the number of vectors that are stored in the neuroRBF automatically by computing the good value.
        DLLEXP unsigned int setnumCenters(unsigned int nCenters);    ///< Sets the number of vectors that are stored in the neuroRBF. This function should not be used except by expert users.
        DLLEXP float setmu(float val);                    ///< Sets the splitting parameter in the neuroRBF. This function should not be used except by expert users.
        DLLEXP int setmode(int val);                    ///< Sets the kernelling mode in the neuroRBF. This function should not be used except by expert users.
        DLLEXP int setvWidth(int size);                    ///< Sets the Width of original data samples (before resizing).
        DLLEXP int setvHeight(int size);                ///< Sets the Height of original data samples (before resizing).
        DLLEXP bool setresizeFlag(bool flag);                ///< Sets the resizeFlag that indicate if resizing should take place.

        DLLEXP int neuroRBFCatExists(int catID);    ///< Adds a category to the current learning base.
        DLLEXP int addNeuroRBFCat();    ///< Adds an empty category to the current learning base.
        DLLEXP int addNeuroRBFCat(int catID);    ///< Adds an empty category to the current learning base specifying the catID.
        DLLEXP int addNeuroRBFCat(neuroRBFCat cat);    ///< Adds a category a copy of the category cat to the current learning base.
        DLLEXP int addNeuroRBFCat(neuroRBFCat cat, unsigned int place);    ///< Adds a category a copy of the category cat to the current learning base at the specified place.
        DLLEXP int removeNeuroRBFCat(int catID);    ///< Not yet implemented. Removes a category from the learning base using its catID.
        DLLEXP int removeNeuroRBFCat(string label);    ///< Not yet implemented. Removes a category from the learning base using its label.***NYI***

        DLLEXP int addVectToCat(vector <int> vect, int catID);        ///< Adds a vector to the catID category base.
        DLLEXP int addCenterToCat(vector<int> center, int catID, int rad = 0, int learn = 1);    ///< Adds a new example to the center base of the category designated by the int cat.
        DLLEXP int removeVectFromCat(vector <int> vect, int catID);    ///< Removes the given vector from the catID category base.
        DLLEXP int removeVectFromCat(int vectID, int catID);        ///< Removes the vector with vectID from the catID category base.

        DLLEXP int genUpdate();                            ///< Puts centers of all categories into genLB and update genRad and genCat accordingly.
        DLLEXP int kernneuroRBF();                            ///< Puts example together into centers i.e. reduces the number of centers to be learned.
        DLLEXP int learnneuroRBF();                            ///< Performs the learning computation for the network object. It firstly calls kernneuroRBF() function
        DLLEXP int compRadneuroRBF();                        ///< Computes the radius for every centers of the neuroRBF instance.
        DLLEXP int learnCat(neuroRBFCat* netCatP);            ///< Perform learning over categories. Called internally and should not be called manually.

        DLLEXP int recallneuroRBF( vector<float>& V);            ///< Uses the neuroRBF to categorized the given reference on float vector V.
        DLLEXP int recallneuroRBF( vector<int>& V);            ///< Uses the neuroRBF to categorized the given reference on int vector V.
        DLLEXP int recallneuroRBF( vector<unsigned char>& V);    ///< Uses the neuroRBF to categorized the given reference on unsigned char vector V. This is useful when dealing with image whose data is usually ranged form 0 to 255 (i.e. unsigned char or uchar).

        DLLEXP int fastRecallneuroRBF(vector<int>& V);        ///< Fast recognition for neuroRBF this function is undertest.

        DLLEXP int legacyRecallneuroRBF(vector<int>& V);    ///< Legacy recognition for neuroRBF to categorized the given reference on int vector V. This function is undertest.
        DLLEXP int legacyRecallneuroRBF(vector<unsigned char>& V); ///< Legacy recognition for neuroRBF to categorized the given reference on unsigned char vector V. This is useful when dealing with image whose data is usually ranged form 0 to 255 (i.e. unsigned char or uchar). This function is undertest.
        DLLEXP int legacyRecallneuroRBF(arma::Col<int>& V);///< Legacy recognition for neuroRBF to categorized the given reference on arma matrix of int. This function is undertest.

        DLLEXP int saveneuroRBF(char* filename);            ///< Saves neuroRBF as a text file.
        DLLEXP int saveneuroRBF(const char* filename);        ///< Saves neuroRBF as a text file from a const char*.
        DLLEXP int save2neuroRBF(char* filename);            ///< Saves neuroRBF as a text file for legacy learning support.
        DLLEXP int save2neuroRBF(const char* filename);        ///< Saves neuroRBF as a text file from a const char* for legacy learning support.
        DLLEXP int restoreneuroRBF(char* filename);            ///< Loads a previously saved neuroRBF.
        DLLEXP int restoreneuroRBF(const char* filename);    ///< Loads a previously saved neuroRBF from a const char*.

        vector<float> val;                            ///< Array that stores the score of the tested vector for each category.
        vector<int> dif;                            ///< Array that stores the distance between vector under test and the nearest center in each category.
        vector<int> cent;                            ///< Array that stores the nearest center of the vector under test in each category.
        int reccat;                                        ///< Result of the categorization.
        string reclabel;                                ///< Label of the recognized categorization.
        float recval;                                    ///< Recognition strength of the categorisation.
        int reccenter;                                 ///< Nearest center in the recognized category.
        vector< neuroRBFCat >::iterator netCatIt;    ///< Default Iterator for the category list.
        vector< vector<int> > scores;            ///< save of the last recognition scores for every center.
        vector< vector<int> > sumScores;        ///< save of the last recognition cumulative scores for every center.

        arma::fmat OL;                ///< Output layer transform for the RBF classifier.
        float tol;                    ///< Tolerance parameter for final classification.

    private:
        int numCat;                    ///< ID number of learned classes.
        unsigned int vSize;            ///< Size of learned vectors.
        unsigned int numCenters;    ///< Total number of learned vectors.
        float mu;                    ///< Distance splitting parameter.
        int mode;                    ///< Sets the kernelling function on/off (default is 1 i.e kernelling ON). Mode set to 0 puts kernelling function OFF).

        int vWidth;                ///< Original size of the ROI in X dimension. This vWidth should be at least equal to 1.
        int vHeight;            ///< Original size of the ROI in Y dimension. This vHeight should be at least equal to 1 even if signal is on one dimension.

        bool resizeFlag;        ///< Flag used to check if vectors have to be resized to vSize from ROI of size vWidth*vHeight.

        vector< vector<int> > fullLB;    ///< Complete LB unaffected by kernelling to keep the original values in the network
        vector<int> fullCat;            ///< Complete CatID of vectors in fullLB, unaffected by kernelling to keep the original values in the network

        vector< vector<int> > genLB;    ///<temporary general LB, changed during learning.
        vector<int> genCat;                ///<temporary general CatID list of vectors in genLB changed during learning.
        vector<int> genRad;                ///<temporary general radius list of vectors in genLB changed during learning.

        arma::Mat<int>genArmaLB;

        vector<neuroRBFCat> netCat;///<List of categories that compose the network.
    };///< The neuroRBF class define the RBF model. Each instance of e neuroRBF is an RBF network with its own vector size and learned examples.
}
#endif    /* neuroRBF_H*/
