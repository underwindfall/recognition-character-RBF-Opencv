#ifndef NEURORECO_H
#define    NEURORECO_H
#include <iostream>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{
    using namespace std;

    class neuroreco {
        DLLEXP friend ostream &operator<<(ostream &, const neuroreco &);                ///< This friend function allows the display of principal members of the NEURORECO instance. This function is does not provide a complet display of the object instance so it should not be used to save neuroRBFCat to a file.
        DLLEXP friend vector<neuroreco> computeBarycenter(vector<neuroreco> data);
        DLLEXP friend neuroreco computeBarycenter(vector<neuroreco> data, int cat);
    public:
        DLLEXP neuroreco();                        ///< Default neuroreco constructor.
        DLLEXP neuroreco(int xx, int yy, int rreccenter, int rreccat, int ddif, int vval);///< Fully specified neuroreco constructor.
        DLLEXP neuroreco(const neuroreco& orig);    ///< Copy constructor.
        DLLEXP virtual ~neuroreco();            ///< Destructor.

        DLLEXP neuroreco &operator=(const neuroreco &orig);        ///< Affectation operator definition.
        DLLEXP int operator==(const neuroreco &orig) const;        ///< EQ comparision operator definition.
        DLLEXP int operator<(const neuroreco &orig) const;        ///< LT comparision operator definition.
        DLLEXP int operator>(const neuroreco &orig) const;        ///< GT comparision operator definition.

        int x;            ///< Position of the hit in x dimension.
        int y;            ///< Position of the hit in y dimension.
        int reccat;            ///< Recognized category.
        int reccenter;        ///< Nearest center from the recongized vector.
        int dif;            ///< difference between recongized vector and nearest center.
        float val;            ///< value of the recognition strength.
    };///< Neuroreco objects are used to collect details about the last recognition trial issued to the neuroRBF.
}
#endif /*NEURORECO_H*/
