#ifndef NEARESTNEIGHBOR_H
#define NEARESTNEIGHBOR_H

#include <vector>
#include <istream>
#include <ostream>
#include "AbstractClassifier.h"

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

namespace gst
{

    class NearestNeighbor : public AbstractClassifier
    {
    public:

        DLLEXP NearestNeighbor() {}

        DLLEXP NearestNeighbor(const std::string& path) { read(path); }

        DLLEXP NearestNeighbor(std::ifstream& ifs) { read(ifs); }

        DLLEXP void train(const std::vector<std::vector<float> >& vectors, const std::vector<float> labels);

        DLLEXP void scorePerClass(const std::vector<float>& v, std::vector<std::pair<double, float>>* scores) const;

        DLLEXP double classify(const std::vector<float>& v) const;

        DLLEXP void read(std::istream& is);

        DLLEXP void read(const std::string& path) { Readable::read(path); }

        DLLEXP void write(std::ostream& os) const;

        DLLEXP void write(const std::string& path) const { Writable::write(path); }

        DLLEXP virtual AbstractClassifier* clone() const;

        static const long long ID = 201505022229;


    private:

        class Center
        {
            friend NearestNeighbor;

            DLLEXP Center(const std::vector<float>& vector, float label) : vector(vector), label(label) {}
            std::vector<float> vector;
            float label;
        };

        std::vector<Center> centers;
    };

}

#endif /* NEARESTNEIGHBOR_H*/
