#ifndef ABSTRACTCLASSIFIER_H
#define ABSTRACTCLASSIFIER_H

#include <vector>
#include <istream>
#include <ostream>
#include "GST/core/Writable.h"
#include "GST/core/Readable.h"

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

namespace gst
{

    class AbstractClassifier : public Writable, public Readable
    {
    public:

        DLLEXP virtual ~AbstractClassifier() {}

        DLLEXP virtual void train(const std::vector<std::vector<float> >& vectors, const std::vector<float> labels) = 0;

        DLLEXP virtual void scorePerClass(const std::vector<float>& v, std::vector<std::pair<double, float>>* scores) const = 0;

        DLLEXP virtual double classify(const std::vector<float>& v) const = 0;

        DLLEXP virtual AbstractClassifier* clone() const = 0;

    };

}

#endif /* ABSTRACTCLASSIFIER_H*/
