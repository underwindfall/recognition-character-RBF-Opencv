#ifndef HMINCLASSIFIERPIPELINE
#define HMINCLASSIFIERPIPELINE

#include "GST/core/Writable.h"
#include "GST/core/Readable.h"
#include "GST/hmax/HMin.h"
#include "GST/classifiers/SvmDlibWrapper.h"
#include <vector>
#include <string>
#include <opencv2/opencv.hpp>
#include <istream>
#include <fstream>

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

namespace gst
{

    class HMinClassifierPipeLine : public Writable
    {

    public:

        /**
        * Constructor.
        */
        DLLEXP HMinClassifierPipeLine(AbstractClassifier* classifier = new SvmDlibWrapper()) : hmin(new HMin()), classifier(classifier) {}

        /**
        * Constructor.
        */
        DLLEXP HMinClassifierPipeLine(HMin* hmin, AbstractClassifier* classifier = new SvmDlibWrapper()) : hmin(hmin), classifier(classifier) {}

        /**
        * Copy constructor.
        */
        DLLEXP HMinClassifierPipeLine(const HMinClassifierPipeLine& orig);

        /**
        * Destructor.
        */
        DLLEXP ~HMinClassifierPipeLine();

        /**
        * Setting operator overloading.
        */
        DLLEXP HMinClassifierPipeLine& operator=(const HMinClassifierPipeLine& orig);

        DLLEXP void train(const std::vector<cv::Mat>& trainingBase, std::vector<float> labels);

        DLLEXP void train(std::istream& ifs);

        DLLEXP void train(const std::string& configFilepath);

        DLLEXP void train(const std::vector<std::string>& filePaths, const std::vector<float>& labels, size_t resizeWidth = 128, size_t resizeHeight = 128);

        DLLEXP float classify(const cv::Mat& im) const;

        DLLEXP void write(std::ostream& os) const;

        DLLEXP void write(const std::string& path) const { Writable::write(path); }

        DLLEXP static HMinClassifierPipeLine* load(std::ifstream& is);

        static const long long ID = 201511161659;

    private:

        AbstractClassifier* classifier;

        HMin* hmin;

    };

}

#endif /* HMINCLASSIFIERPIPELINE*/
