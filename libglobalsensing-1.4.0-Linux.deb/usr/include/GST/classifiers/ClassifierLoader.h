#ifndef CLASSIFIERLOADER_H
#define CLASSIFIERLOADER_H

#include "GST/classifiers/AbstractClassifier.h"
#include <istream>
#include <fstream>

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

namespace gst
{

    class ClassifierLoader
    {
    public:

        DLLEXP static AbstractClassifier* load(std::ifstream& ifs);

        DLLEXP static AbstractClassifier* load(const std::string& path);

        /* <DEPRECATED>*/
        DLLEXP static void load(std::ifstream& ifs, AbstractClassifier* out);
        DLLEXP static void load(const std::string& path, AbstractClassifier* out);
        /* </DEPRECATED>*/
    };

}

#endif /* CLASSIFIERLOADER_H*/
