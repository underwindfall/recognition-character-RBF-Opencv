#ifndef SVMDLIBWRAPPER_H
#define SVMDLIBWRAPPER_H

#include <vector>
#include <istream>
#include <ostream>
#include "AbstractClassifier.h"

#if defined(_WIN32)
#   define DLLEXP __declspec(dllexport)
#else
#   define DLLEXP
#endif

namespace gst
{

class SvmDlibWrapper : public AbstractClassifier
{
public:

    DLLEXP SvmDlibWrapper();

    DLLEXP SvmDlibWrapper(const std::string& path) { read(path); }

    DLLEXP SvmDlibWrapper(std::ifstream& ifs);

    DLLEXP SvmDlibWrapper(const SvmDlibWrapper& orig);

    DLLEXP SvmDlibWrapper& operator=(const SvmDlibWrapper& orig);

    DLLEXP size_t getInputVectorSize() const;

    DLLEXP size_t getNbCategories() const;

    DLLEXP void train(const std::vector<std::vector<float> >& vectors, const std::vector<float> labels);

    DLLEXP void scorePerClass(const std::vector<float>& v, std::vector<std::pair<double, float>>* scores) const;

    DLLEXP double classify(const std::vector<float>& v) const;

    DLLEXP void read(std::istream& is);

    DLLEXP void read(const std::string& path) { Readable::read(path); }

    DLLEXP void write(std::ostream& os) const;

    DLLEXP void write(const std::string& path) const { Writable::write(path); }

    DLLEXP virtual AbstractClassifier* clone() const;

    static const long long ID = 201505022238;

private:

    class SvmDlibWrapperCheshireCat;
    SvmDlibWrapperCheshireCat* smile;

};

}

#endif /* SVMDLIBWRAPPER_H*/
