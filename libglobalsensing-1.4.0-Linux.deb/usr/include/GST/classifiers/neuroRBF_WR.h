#ifndef NEURORBF_WR_H
#define    NEURORBF_WR_H

#include "neuroRBF.h"
#include "neuroRBFCat.h"

namespace gst
{
    extern "C" __declspec(dllexport) neuroRBF* New_neuroRBF()                ///< Creates a default and empty neuroRBF.
    {
        return new neuroRBF();
    }

    extern "C" __declspec(dllexport) neuroRBF* Copy_neuroRBF(const neuroRBF& orig)    ///< Creates a neuroRBF by copying an other neuroRBF provided as a parameter.
    {
        return new neuroRBF(orig);
    }

    extern "C" __declspec(dllexport) void Delete_neuroRBF(neuroRBF* np)            ///< Destroyes the neuroRBF.
    {
        delete np;
    }

    extern "C" __declspec(dllexport) int NP_getnumCat(neuroRBF* np)                        ///< Returns the number of category.
    {
        return np->getnumCat();
    }

    extern "C" __declspec(dllexport) unsigned int NP_getvSize(neuroRBF* np)                ///< Returns the size of vectors to be classified.
    {
        return np->getvSize();
    }

    extern "C" __declspec(dllexport) unsigned int NP_getnumCenters(neuroRBF* np)            ///< Returns the number of centers that compose the learning base.
    {
        return np->getnumCenters();
    }

    extern "C" __declspec(dllexport) float NP_getmu(neuroRBF* np)                        ///< Returns the distance splitting parameter.
    {
        return np->getmu();
    }

    extern "C" __declspec(dllexport) int NP_getmode(neuroRBF* np)                        ///< Returns the mode parameter.
    {
        return np->getmode();
    }

    __declspec(dllexport) std::vector<neuroRBFCat> NP_getnetCat(neuroRBF* np)                ///< Returns the list of categories.
    {
        return np->getnetCat();
    }

    __declspec(dllexport) neuroRBFCat NP_getCat(neuroRBF* np, int catID)                    ///< Returns the cat th element of network categories as a constant.
    {
        return np->getnetCat(catID);
    }

    extern "C" __declspec(dllexport) int NP_getCatColor(neuroRBF* np, int catID)        ///< Returns the color of the categories of the category with ID catID.
    {
        return np->getnetCatColor(catID);
    }

    __declspec(dllexport) string NP_getCatLabel(neuroRBF* np, int catID)        ///< Returns the color of the categories of the category with ID catID.
    {
        return np->getnetCatLabel(catID);
    }

    extern "C" __declspec(dllexport) int NP_getvWidth(neuroRBF* np)                    ///< Returns the original size of the data Roi in the x dimension.
    {
        return np->getvWidth();
    }

    extern "C" __declspec(dllexport) int NP_getvHeight(neuroRBF* np)                    ///< Returns the original size of the data Roi in the y dimension.
    {
        return np->getvHeight();
    }

    extern "C" __declspec(dllexport) int NP_setnumCat(neuroRBF* np)                            ///< Sets the number of category in the neuroRBF automatically by computing the good value.
    {
        return np->setnumCat();
    }

    extern "C" __declspec(dllexport) int NP_userSetnumCat(neuroRBF* np, int nCat)                    ///< Sets the number of category in the neuroRBF. This function should not be used except expert users.
    {
        return np->setnumCat(nCat);
    }

    extern "C" __declspec(dllexport) unsigned int NP_setvSize(neuroRBF* np)                    ///< Sets the size of vectors that will be categorizes in the neuroRBF automatically by computing the good value.
    {
        return np->setnumCat();
    }

    extern "C" __declspec(dllexport) unsigned int NP_userSetvSize(neuroRBF* np, unsigned int size)    ///< Sets the size of vectors that will be categorizes in the neuroRBF. This function should not be used except by expert users.
    {
        return np->setvSize(size);
    }

    extern "C" __declspec(dllexport) unsigned int NP_setnumCenters(neuroRBF* np)                        ///< Sets the number of vectors that are stored in the neuroRBF automatically by computing the good value.
    {
        return np->setnumCenters();
    }

    extern "C" __declspec(dllexport) unsigned int NP_userSetnumCenters(neuroRBF* np, unsigned int nCenters)///< Sets the number of vectors that are stored in the neuroRBF. This function should not be used except by expert users.
    {
        return np->setnumCenters(nCenters);
    }

    extern "C" __declspec(dllexport) float NP_setmu(neuroRBF* np, float val)                    ///< Sets the splitting parameter in the neuroRBF. This function should not be used except by expert users.
    {
        return np->setmu(val);
    }

    extern "C" __declspec(dllexport) int NP_setmode(neuroRBF* np, int val)                        ///< Sets the kernelling mode in the neuroRBF. This function should not be used except by expert users.
    {
        return np->setmode(val);
    }

    extern "C" __declspec(dllexport) int NP_setvWidth(neuroRBF* np, int size)
    {
        return np->setvWidth(size);
    }

    extern "C" __declspec(dllexport) int NP_setvHeight(neuroRBF* np, int size)
    {
        return np->setvHeight(size);
    }

    extern "C" __declspec(dllexport) int NP_neuroRBFCatExists(neuroRBF* np, int catID)    ///< Adds a category to the current learning base.
    {
        return np->neuroRBFCatExists(catID);
    }

    extern "C" __declspec(dllexport) int NP_addNeuroRBFCat(neuroRBF* np, neuroRBFCat cat)    ///< Adds a category to the current learning base.
    {
        return np->addNeuroRBFCat(cat);
    }

    extern "C" __declspec(dllexport) int NP_removeNeuroRBFCat(neuroRBF* np, int cat)    ///< Removes a category from the learning base.
    {
        return np->removeNeuroRBFCat(cat);
    }

    extern "C" __declspec(dllexport) int NP_addCenterToCat(neuroRBF* np, vector<float> center, int cat,float rad = 0, int learn = 1)        ///< Adds a new example to the center base of the category designated by the int cat.
    {
        return np->addCenterToCat(center,cat,rad,learn);
    }

    extern "C" __declspec(dllexport) int NP_removeCenterFromCat(neuroRBF* np, vector<float> center, int cat)            ///< Not yet implemented. Removes an example from the center base of the category designated by the int cat.
    {
        return np->removeCenterFromCat(center,cat);
    }

    extern "C" __declspec(dllexport) int NP_kernneuroRBF(neuroRBF* np)    ///< Puts example together into centers i.e. reduces the number of centers to be learned.
    {
        return np->kernneuroRBF();
    }

    extern "C" __declspec(dllexport) int NP_learnneuroRBF(neuroRBF* np)    ///< Performs the learning computation for the network object. It firstly calls kernneuroRBF() function
    {
        return np->learnneuroRBF();
    }

    extern "C" __declspec(dllexport) int NP_compRadneuroRBF(neuroRBF* np)    ///< Computes the radius for every centers of the neuroRBF instance.
    {
        return np->compRadneuroRBF();
    }

    extern "C" __declspec(dllexport) int NP_saveneuroRBF(neuroRBF* np, char* filename)            ///< Saves neuroRBF as a text file.
    {
        return np->saveneuroRBF(filename);
    }

    extern "C" __declspec(dllexport) int NP_saveneuroRBFConst(neuroRBF* np, const char* filename)        ///< Saves neuroRBF as a text file from a const char*.
    {
        return np->saveneuroRBF(filename);
    }

    extern "C" __declspec(dllexport) int NP_restoreneuroRBF(neuroRBF* np, char* filename)            ///< Loads a previously saved neuroRBF.
    {
        return np->restoreneuroRBF(filename);
    }

    extern "C" __declspec(dllexport) int NP_restoreneuroRBFConst(neuroRBF* np, const char* filename)    ///< Loads a previously saved neuroRBF from a const char*.
    {
        return np->restoreneuroRBF(filename);
    }

    extern "C" __declspec(dllexport) int NP_recallneuroRBF(neuroRBF* np, vector<float> V)            ///< Uses the neuroRBF to categorized the given float vector V.
    {
        return np->recallneuroRBF(V);
    }

    extern "C" __declspec(dllexport) int NP_recallneuroRBFUInt(neuroRBF* np, vector<unsigned char> V)    ///< Uses the neuroRBF to categorized the given unsigned char vector V. This is useful when dealing with image whose data is usually ranged form 0 to 255 (i.e. unsigned char or uchar);
    {
        return np->recallneuroRBF(V);
    }
}

#endif //NEURORBF_WR_H