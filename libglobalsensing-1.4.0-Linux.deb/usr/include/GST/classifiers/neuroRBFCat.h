/*
* File:   neuroRBFCat.h
* Author: Olivier Brousse
*
* Created on 31 octobre 2012, 17:59
*/

#ifndef NEURORBFCAT_H
#define    NEURORBFCAT_H
#include <iostream>
#include <list>
#include <vector>
#include <GST/core/gst.h>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{
    using namespace std;

    class neuroRBFCat {
        DLLEXP friend ostream &operator<<(ostream &, const neuroRBFCat &);

    public:
        DLLEXP neuroRBFCat();                        ///< default neuroRBFCat constructor.
        DLLEXP neuroRBFCat(const neuroRBFCat& orig);    ///< copy constructor.
        DLLEXP virtual ~neuroRBFCat();            ///< destructor.

        DLLEXP neuroRBFCat &operator=(const neuroRBFCat &orig);        ///< affectation operator definition.
        DLLEXP int operator==(const neuroRBFCat &orig) const;        ///< eq comparision operator definition.
        DLLEXP int operator<(const neuroRBFCat &orig) const;        ///< lt comparision operator definition.
        DLLEXP int operator>(const neuroRBFCat &orig) const;        ///< gt comparision operator definition.

        DLLEXP int addVector(vector<int> vect); ///< adds the given vecor as an example in the category.
        DLLEXP int removeVector(vector<int> vect);    ///< Removes the provided example from the category if it exists in its learning base.
        DLLEXP int removeVector();    ///< Removes the last example provided to the category.

        DLLEXP int learnCat(vector< vector<int> > LB);    ///< Provokes the learning of this particular neuroRBFCat. This function is provided to learn when the recallNeuroRBF function is used for recognition only. It should not be used for any other purpose.

        DLLEXP int setcSize();    ///< Set the cSize parameter from the actual number of examples in the category.

        DLLEXP void clear();        ///< Reset neuroRBFCat to default value

        int catNum;        ///< number of the class
        int vSize;        ///< size of learned vectors
        int cSize;        ///< number of vectors learned for the class
        string label;    ///< string label of the category
        int color;        ///< color label of the category

        vector< vector<int> > lb;    ///< actual values of stored vectors called "learned base". This part is user interface with the model. Data for learning should be fed in this variable.
        vector<int> r;            ///< vector that contains radius valuesset to 0 when network is not kerneled. These values automatically computed during the kerneling phase. THESE DATA SHOULD NOT BE EDITED BY USER EXPECT BY ANN EXPERTS.
        vector< vector<float> > P;    ///< square matrix of size "cSize" that contains training informations set to 0 when network is not trained. These values automatically computed during the learning phase. THESE DATA SHOULD NOT BE EDITED BY USER EXPECT.
        vector<float> TQD;            ///< vector that contain training informations set to 0 when network is not trained. These values automatically computed during the learning phase. THESE DATA SHOULD NOT BE EDITED BY USER EXPECT BY ANN EXPERTS.
    };
}
#endif    /* NEUROCAT_H*/
