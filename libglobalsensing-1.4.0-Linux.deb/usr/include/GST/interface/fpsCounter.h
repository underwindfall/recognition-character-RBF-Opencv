/*!
* \file fpsCount.cpp
* \brief This class implements the frmae per second counter
* \author G. SAUVAGE
* \version 0.1
* \date 03/04/2015
*
* This class implements the calcul for time to work on image
*
*/

#ifndef FPSCOUNTER_H
#define FPSCOUNTER_H

#include <iostream>
#include <sys/timeb.h>

#if defined(_MSC_VER) || defined(WIN32)  || defined(_WIN32) || defined(__WIN32__) \
    || defined(WIN64)    || defined(_WIN64) || defined(__WIN64__)

#include <windows.h>

#define DLLEXP __declspec(dllexport)

bool _qpcInited=false;
double PCFreq = 0.0;
__int64 CounterStart = 0;

void InitCounter()
{
    LARGE_INTEGER li;
    if(!QueryPerformanceFrequency(&li))
    {
        std::cout << "QueryPerformanceFrequency failed!\n";
    }
    PCFreq = double(li.QuadPart)/1000.0f;
    _qpcInited=true;
}

double CLOCK()
{
    if(!_qpcInited) InitCounter();
    LARGE_INTEGER li;
    QueryPerformanceCounter(&li);
    return double(li.QuadPart)/PCFreq;
}

#endif

#if defined(unix)        || defined(__unix)      || defined(__unix__) \
    || defined(linux)       || defined(__linux)     || defined(__linux__) \
    || defined(sun)         || defined(__sun) \
    || defined(BSD)         || defined(__OpenBSD__) || defined(__NetBSD__) \
    || defined(__FreeBSD__) || defined __DragonFly__ \
    || defined(sgi)         || defined(__sgi) \
    || defined(__MACOSX__)  || defined(__APPLE__) \
    || defined(__CYGWIN__)

#define DLLEXP

double CLOCK()
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC,  &t);
    return (t.tv_sec* 1000)+(t.tv_nsec*1e-6);
}
#endif

namespace gst
{

    class fpsCounter
    {
        public :
            fpsCounter():_avgdur(0),_fpsstart(0),_avgfps(0),_fps1sec(0){}
            ~fpsCounter(){}
            DLLEXP inline double avgdur(double newdur);
            DLLEXP inline double avgfps();
        private :
            double _avgdur;
            double _fpsstart;
            double _avgfps;
            double _fps1sec;
    };

    inline double fpsCounter::avgdur(double newdur)
    {
            _avgdur=0.98*_avgdur+0.02*newdur;
            return _avgdur;
    }

    inline double fpsCounter::avgfps()
    {
            if(CLOCK()-_fpsstart>1000)
             {
                _fpsstart=CLOCK();
                _avgfps=0.7*_avgfps+0.3*_fps1sec;
                _fps1sec=0;
        }
            _fps1sec++;
            return _avgfps;
    }
}

#endif /*FPSCOUNTER_H*/
