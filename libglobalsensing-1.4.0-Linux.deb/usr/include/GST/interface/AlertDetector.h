/*
* File:   filter.h
* Author: olivier
*
* Created on 13 novembre 2014, 13:48
*/

#ifndef ALERTDETECTOR_H
#define    ALERTDETECTOR_H

#include <vector>

namespace gst
{
    /**
    * Detect alert.
    *
    * This class allows to detect an alert, given inputs accross time. To use
    * it, one must first call its constructor, and the simply call several
    * times alert().
    */
    class AlertDetector
    {
    public:
        /**
        * Constructor.
        *
        * @param threshold number of successive "true" input in alert before raising an alarm
        */
        AlertDetector(const unsigned int threshold);


        /**
        * Constructor.
        *
        * @param thresholdMax number of successive "true" input in alert before raising up an alarm
        * @param thresholdMin number of successive "false" input in alert before raising down an alarm
        */
        AlertDetector(const unsigned int thresholdMax,const unsigned int thresholdMin );

        /**
        * Detect alert.
        *
        * Every time this function is call, if in is true, an internal counter
        * is incremented, otherwise it's set to 0. If the counter's value
        * reaches the value of the threshold member, true is returned - which
        * means that an alarm was raised. Otherwise, false is returned.
        *
        * @param in true to increment counter, false to set it back to 0
        * @return true in case of an alert, false otherwise
        */
        bool alert(bool in);

        /**
        * Destructor.
        */
        virtual ~AlertDetector();

    private:



        /**
        * Threshold at which we raise down an alarm.
        */
        const unsigned int thresholdMin;

        /**
        * Threshold at which we raise up an alarm.
        */
        const unsigned int thresholdMax;


        /**
        * Keeps track of the number of successive alarms.
        */
        unsigned int cntUp;

        /**
        * Keeps track of the number of successive no alarms.
        */
        unsigned int cntDown;
    };
}

#endif    /* FILTER_H*/
