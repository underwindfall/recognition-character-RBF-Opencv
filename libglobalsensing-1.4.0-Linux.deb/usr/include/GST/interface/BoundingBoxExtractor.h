/*
* File:   BoundingBoxExtractor.h
* Author: olivier
*
* Created on 19 janvier 2015, 11:06
*/

#ifndef BOUNDINGBOXEXTRACTOR_H
#define    BOUNDINGBOXEXTRACTOR_H

#include <opencv2/opencv.hpp>
#include <vector>
#include <cmath>
#include <exception>
#include <stdexcept>

#include <string>
//#include "profiling.h"
#include "ImageBlobs.h"
#include "GST/interface/BoundingBoxChecker.h"

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif
namespace gst
{
    struct Region {
            unsigned int elements_number;
            vector<Rect> bounding_boxes;      //[top,left; right,bottom)
    };

    class BoundingBoxExtractor
    {
    public:

        DLLEXP BoundingBoxExtractor();

        DLLEXP BoundingBoxExtractor(int blurValue, int thresh);

        DLLEXP virtual ~BoundingBoxExtractor();

        DLLEXP void getBoundingBoxes(const cv::Mat& im, std::vector<cv::Rect>* out);

        DLLEXP void getShadowFilteredBoundingBoxes(const cv::Mat& im, std::vector<cv::Rect>* out);

        DLLEXP void filterbyAreaBoundingBoxes(const std::vector<cv::Rect>& in,std::vector<cv::Rect>& out);

        DLLEXP void filterbyPositionBoundingBoxes(const std::vector<cv::Rect>& in,std::vector<cv::Rect>& out);

        DLLEXP void extractBoundingBoxesFromMOG(const cv::Mat& in, std::vector<cv::Rect>* out);

        DLLEXP void reset(){};

        DLLEXP BoundingBoxChecker& getBoundingBoxChecker(){return boundingBoxChecker;};

        DLLEXP int getBlurValue () const {return blurValue;}

        DLLEXP void setBlurValue(int blurValue);

        DLLEXP void setseSize(size_t size);

        DLLEXP void setse1Size(size_t size);

        DLLEXP int getThresh() const { return thresh; }

        DLLEXP int getShadowThresh() const { return shadowThresh; }

        DLLEXP void setThresh (int thresh);

        DLLEXP void setShadowThresh(int shadowThresh);

        DLLEXP const cv::Mat& getLastMogImage() const {return lastMogImage;}

        DLLEXP cv::Mat& getLastMogImage() { return lastMogImage; }

        DLLEXP const cv::Mat& getLastBlurImage() const {return lastBlurImage;}

        DLLEXP cv::Mat& getLastBlurImage() { return lastBlurImage; }

        DLLEXP const cv::Mat& getLastContourImage() const {return lastContourImage;}

        DLLEXP cv::Mat& getLastContourImage() { return lastContourImage; }

        DLLEXP void setminDistToMerge(int value);

        DLLEXP void setContours(std::vector< std::vector< cv::Point> > contours){contours.swap(_contours);}

    private:

        BoundingBoxChecker boundingBoxChecker;

        cv::BackgroundSubtractorMOG2 pMOG2;

        int thresh;

        int shadowThresh;

        int blurValue;

        int minDistToMerge;

        size_t se_size = 3;
        size_t se1_size = 20;

        ImageBlobs myblob;

        cv::Mat lastMogImage;

        cv::Mat lastBlurImage;

        cv::Mat lastContourImage;

        std::vector< std::vector<cv::Point> > _contours;

        void init(int blurValue, int thresh);


    };
}
#endif    /* BOUNDINGBOXEXTRACTOR_H*/
