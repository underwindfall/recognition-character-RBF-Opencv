#ifndef BLURBACKGROUND_H
#define BLURBACKGROUND_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include <opencv2/opencv.hpp>
namespace gst
{
    DLLEXP void blurbackground(const cv::Mat& roi, const cv::Mat& mask, size_t filterSize, cv::Mat* out);
}
#endif /* BLURBACKGROUND_H*/
