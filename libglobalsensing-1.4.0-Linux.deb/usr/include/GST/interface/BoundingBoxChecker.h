/*
* File:   BoundingBoxChecker.h
* Author: olivier
*
* Created on 19 janvier 2015, 11:45
*/

#ifndef BOUNDINGBOXCHECKER_H
#define    BOUNDINGBOXCHECKER_H

#include <opencv2/opencv.hpp>
#include "ImageBlobs.h"

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

using namespace cv;
namespace gst
{
    class BoundingBoxChecker
    {
    public:
        DLLEXP BoundingBoxChecker(float minSurface = 10.0f, float maxSurface = 120000.0f);
        DLLEXP virtual ~BoundingBoxChecker ();

        DLLEXP int check(const cv::Rect& boundingBox);

        const static int OK = 1;
        const static int TOO_SMALL = -1;
        const static int TOO_BIG = -2;

        DLLEXP float getMinSurface() const {return minSurface;}

        DLLEXP void setMinSurface(float minSurface);

        DLLEXP float getMaxSurface() const {return maxSurface;}

        DLLEXP void setMaxSurface(float maxSurface);

        DLLEXP void MergeRect(vector<Rect>&List, double eps, std::vector<cv::Rect>* out,double maxSurface);

        DLLEXP bool isInPolygon(const Point& P, std::vector<Point>& contours);

        DLLEXP bool isInPolygon(const Rect& A, std::vector<Point>& contours);
    private:

        float minSurface;

        float maxSurface;

        bool static sortRectbyArea(const Rect& A, const Rect& B);

        bool static  sortRectbyPos(const Rect& A,const Rect& B);

        bool isInDistance(const Point& A, const Point& B, double eps);

        bool isInRectangle(const Rect& A, const Rect& B);

        bool isInDistance(const Rect& A, const Rect& B, double eps);

        double distance_to_line(const Point& P,const Point& L1,const Point& L2 );




    };
}
#endif    /* BOUNDINGBOXCHECKER_H*/
