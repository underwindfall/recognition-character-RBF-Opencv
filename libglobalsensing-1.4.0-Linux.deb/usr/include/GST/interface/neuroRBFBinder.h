#ifndef NEURORBFBINDER_H
#define NEURORBFBINDER_H

#include <GST/classifiers/neuroRBF.h>
#include <GST/classifiers/neuroreco.h>

#include <opencv2/opencv.hpp>
#include <omp.h>
#include <string.h>
#include <vector>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{
    DLLEXP int initialise_neuroRBF(neuroRBF*net, char*filepath);
    DLLEXP int neuroRBF_scan(neuroRBF*net, cv::Mat grey, std::vector<cv::Rect> rosList, std::vector<gst::neuroreco>*result, unsigned int xstep, unsigned int ystep);
    DLLEXP int neuroRBF_scan(neuroRBF*net, cv::Mat grey, cv::Mat ROI, cv::Mat smallROI, std::vector<cv::Rect> rosList, std::vector<gst::neuroreco>*result, unsigned int xstep, unsigned int ystep);
    DLLEXP int neuroRBF_display(neuroRBF net, std::vector<gst::neuroreco> result, cv::Mat*image);
    DLLEXP bool neuroRBF_scanForCat(neuroRBF*net, int catNum, cv::Mat grey, std::vector<cv::Rect> rosList, std::vector<gst::neuroreco>*result, unsigned int xstep, unsigned int ystep);
    DLLEXP bool neuroRBF_scanForCat(neuroRBF*net, string catLabel, cv::Mat grey, std::vector<cv::Rect> rosList, std::vector<gst::neuroreco>*result, unsigned int xstep, unsigned int ystep);
    ///
    ///experimental
    ///
    DLLEXP bool neuroRBFOnBB(gst::neuroRBF &net, cv::Mat &src, std::vector<cv::Rect> &BB, std::vector<int> &results);
    DLLEXP bool neuroRBFOnBB(gst::neuroRBF &net, cv::Mat &src, std::vector<cv::Rect> &BB, std::vector<neuroreco> &results);
    DLLEXP bool sortNeurorecoX(gst::neuroreco i, gst::neuroreco j);
}
#endif
