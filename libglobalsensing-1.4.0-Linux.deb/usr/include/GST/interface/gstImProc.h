#ifndef GSTIMPROC_H
#define GSTIMPROC_H

#include <GST/core/gst.h>

#include <opencv2/opencv.hpp>
#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{
    //experimental
    DLLEXP void dynamicShift(cv::Mat*src, cv::Mat*dst);
    //experimental
    DLLEXP cv::Mat deflicker(cv::Mat Mat1, int strengthcutoff);
    DLLEXP int GSTSD2(cv::Mat* orig, cv::Mat* bckGnd, cv::Mat* out, int sigma, bool initialize, uchar inc = 1, uchar refresh = 1);
    DLLEXP int GSTSD2Tri(cv::Mat* orig, cv::Mat* bckGnd, cv::Mat* out, int sigma, bool initialize, uchar inc = 1, uchar refresh = 1);
    DLLEXP int GSTSD2Bin(cv::Mat* orig, cv::Mat* bckGnd, cv::Mat* out, int sigma, int thresh, bool initialize, uchar inc = 1, uchar refresh = 1);
    DLLEXP int recursiveAverage(cv::Mat* orig, cv::Mat* bckGnd, cv::Mat* out, float alpha);
    DLLEXP int segmentObject(cv::Mat* orig, std::vector< std::vector<int> >* res);

    /**
     * Add black borders to input image so that the resulting image is square.
     *
     * @param src input image
     * @param dst output image
     */
    DLLEXP void squarifyImage(const cv::Mat& src, cv::Mat* dst);
    DLLEXP void squarifyImage(const IplImage& src, IplImage* dst);
    DLLEXP void sharpenImage(const cv::Mat& src, cv::Mat& dst, float amount = 0.5f);

    DLLEXP bool sortRectX(cv::Rect i, cv::Rect j);

}
#endif /*GSTIMPROC_H*/
