//CharRecProcess.h
#ifndef CHARRECPROCESS_H
#define CHARRECPROCESS_H

#include <boost/program_options.hpp>
#include <boost/lambda/bind.hpp>
#define BOOST_FILESYSTEM_VERSION 3
#define BOOST_FILESYSTEM_NO_DEPRECATED
#include <boost/filesystem.hpp>
#include <GST/core/gst.h>
#include <GST/classifiers/neuroRBF.h>
#include <GST/classifiers/neuroreco.h>
#include <GST/interface/neuroRBFBinder.h>
#include <GST/interface/gstImSeg.h>
#include <GST/interface/gstImSave.h>
#include <GST/interface/gstImProc.h>
#include <GST/interface/dbscan.h>
#include <omp.h>

typedef uint8_t BYTE;

namespace fs = boost::filesystem;

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

namespace gst
{
    class searchForStrings
    {
    private:
        int minArea;
        int maxArea;
        int roiMaxWidth;
        int roiMaxHeight;
        int roiMinWidth;
        int roiMinHeight;
        int dbRadius;
        int dbClusterMinSize;
    public:
        DLLEXP searchForStrings();
        DLLEXP searchForStrings(int minArea,
            int maxArea,
            int roiMaxWidth = 30,
            int roiMaxHeight = 30,
            int roiMinWidth = 8,
            int roiMinHeight = 10,
            int dbRadius = 30,
            int dbClusterMinSize = 1);
        DLLEXP ~searchForStrings();
        DLLEXP void run(BYTE* image,
            int imWidth,
            int imHeight,
            neuroRBF& net,
            std::vector<string>& res_str,
            int saveFlag = 0,
            std::string saveRootPath = NULL,
            std::string outputfile = NULL);

        DLLEXP virtual std::string translate(int cat) = 0;//This function is HIGHLY specific to CAFEINE project... It should be virtualized in a class.
    };
}

#endif /*CHARRECPROCESS_H*/