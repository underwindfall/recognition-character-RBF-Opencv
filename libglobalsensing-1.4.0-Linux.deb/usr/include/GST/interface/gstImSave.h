#ifndef GSTIMSAVE_H
#define    GSTIMSAVE_H
#include <opencv2/opencv.hpp>
#include <vector>
#include <cmath>
#include <exception>
#include <stdexcept>
#include <string>
#include <iostream>
#include <iomanip>
#if defined (__UNIX__)
#include <fstream>
#endif

#include <boost/lambda/bind.hpp>
#define BOOST_FILESYSTEM_VERSION 3
#define BOOST_FILESYSTEM_NO_DEPRECATED
#include <boost/filesystem.hpp>

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

using namespace cv;
using namespace std;
namespace fs = boost::filesystem;

namespace gst
{
    DLLEXP enum imType
    {
        GST_IM_PNG,
        GST_IM_JPG,
        GST_IM_BMP,
        GST_IM_WEBP
    };

    DLLEXP void storeROI(cv::Mat& src, std::vector< cv::Rect>& BB, std::string outputPath, imType image_type = GST_IM_PNG);
    DLLEXP void storeSortedROI(cv::Mat& src, std::vector< cv::Rect>& BB, std::vector<string>& labels, std::string outputPath, std::string fileNamePrefix = "" , imType image_type = GST_IM_PNG);
    DLLEXP void storeImage(cv::Mat& img, std::string outputPath, int image_type = 0);
    DLLEXP void storeImageAndAnnotations(cv::Mat& img, std::vector< cv::Rect>& BB, std::string outputPath, int image_type = 0);
}

#endif /*GSTIMSAVE_H*/