#ifndef DBSCAN_H
#define DBSCAN_H
    #include <vector>
    #include <opencv2/opencv.hpp>
    #include <boost/numeric/ublas/matrix.hpp>

    #if defined(_WIN32)
        #define DLLEXP __declspec(dllexport)
    #else
        #define DLLEXP
    #endif


    namespace gst
    {
        class DbScan
        {
        public:

            //memorization table in case of complex dist functions
    #define DP(i,j) dp[(data.size()*i)+j]

            DLLEXP DbScan(std::vector<cv::Rect>& _data, double _eps, int _mnpts);
            DLLEXP void run();
            DLLEXP std::vector<std::vector<cv::Rect> > getGroups();

        //private:
            void expandCluster(int p, std::vector<int> neighbours);

            bool isVisited(int i);

            std::vector<int> regionQuery(int p);

            double dist2d(cv::Point2d a, cv::Point2d b);

            double distanceFunc(int ai, int bi);

            std::map<int, int> labels;
            std::vector<cv::Rect>& data;
            int C;
            double eps;
            int mnpts;
            double* dp;
        };
    }
#endif /*DBSCAN_H*/