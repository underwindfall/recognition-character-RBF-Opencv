#ifndef GSTIMSEG_H
#define GSTIMSEG_H

#include <GST/core/gst.h>

#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <vector>

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

namespace gst
{
    DLLEXP void mserChar(cv::Mat& src, std::vector<cv::Rect> &BB,
        int min_area = 30,
        int max_area = 125,
        int roiMaxWidth = 30,
        int roiMaxHeight = 30,
        int roiMinWidth = 8,
        int roiMinHeight = 10);//default values adapted to CAFEINE v1
    DLLEXP void mserFeatures(cv::Mat& src, cv::MSER ms_orig, std::vector<cv::Rect> &BB);
}
#endif /*GSTIMSEG_H*/