/*
* File:   Readable.h
* Author: olivier
*
* Created on 12 february 2015, 14:09
*/

#ifndef READABLE_H
#define READABLE_H

#if defined(_WIN32)
#define DLLEXP __declspec(dllexport)
#else
#define DLLEXP
#endif

#include <istream>
#include <fstream>
#include <string>

namespace gst
{

/**
* Interface for object that are readable from output stream.
*
* Any class representing data that can be read from a stream
* may inherit this class. The subclass must implement the read()
* method, which takes care of the reading of the data in the output stream.
*
* @see read()
* @see Writable
*/
class Readable
{
public:

    /**
   * Read class instance from input stream.
   *
   * This function is purely virtual and must be implemented by
   * subclass. When implementing it, the user should consider
   * the given stream handle valid, and should NOT call the
   * open() and close() methods or any function that call them.
   *
   * @param is input stream from which to read
   */
    DLLEXP virtual void read(std::istream& is) = 0;

    /**
   * Read class instance from input file.
   *
   * This function opens the file at the given path, read from it
   * using read(std::istream& os), and close it afterwards.
   *
   * @param path path to input file
   * @see read(std::istream& is)
   */
    DLLEXP virtual void read(const std::string& path);

};

}

#endif /* READABLE_H*/
