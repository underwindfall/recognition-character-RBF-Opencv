#ifndef GST_H
#define GST_H

#include <vector>
#include <iostream>
#include <fstream>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{
    DLLEXP bool fexist(const char*filename);
    DLLEXP bool fexist(const wchar_t*filename);
    DLLEXP int pullfloat( char** p_str, float & f );
    DLLEXP std::vector<int> vectmax(std::vector<int>& vect);
    DLLEXP std::vector<unsigned int> vectmax(std::vector<unsigned int>& vect);
    DLLEXP std::vector<int> vectmax(std::vector<unsigned char>& vect);
    DLLEXP std::vector<float> vectmax(std::vector<float>& vect);
    DLLEXP std::vector<int> vectmin(std::vector<int>& vect);
    DLLEXP std::vector<unsigned int> vectmin(std::vector<unsigned int>& vect);
    DLLEXP std::vector<int> vectmin(std::vector<unsigned char>& vect);
    DLLEXP std::vector<float> vectmin(std::vector<float>& vect);
    DLLEXP double round(double number);
    DLLEXP float round(float number);
    #if defined(__UNIX__)
        DLLEXP int gettimeofday(struct timeval* p, void* tz);
    #endif

    /**
    * Check that input stream is correct.
    */
    DLLEXP void checkStream(const std::istream& is);

    /**
    * Check that output stream is correct.
    */
    DLLEXP void checkStream(const std::ostream& os);

}
#endif /*GST_H*/
