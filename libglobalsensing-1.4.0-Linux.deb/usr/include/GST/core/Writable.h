/*
* File:   Writable.h
* Author: olivier
*
* Created on 12 february 2015, 14:10
*/

#ifndef WRITABLE_H
#define WRITABLE_H

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

#include <ostream>
#include <fstream>
#include <string>

namespace gst
{

/**
* Interface for object that are writable in output stream.
*
* Any class representing data that can be written in a stream
* may inherit this class. The subclass must implement the write()
* method, which takes care of the writing of the data in the output stream.
*
* @see write()
* @see Readable()
*/
class Writable
{
public:

    /**
   * Write class instance to output stream.
   *
   * This function is purely virtual and must be implemented by
   * subclass. When implementing it, the user should consider
   * the given stream handle valid, and should NOT call the
   * open() and close() methods or any function that call them.
   *
   * @param os output stream where to write
   */
    DLLEXP virtual void write(std::ostream& os) const = 0;

    /**
   * Write class instance to output file.
   *
   * This function opens the file at the given path and write to it
   * using write(std::ostream& os), and close it afterwards.
   *
   * @param path path to output file
   * @see write(std::ostream& os)
   */
    DLLEXP virtual void write(const std::string& path) const;

};

}

#endif /* WRITABLE_H*/
