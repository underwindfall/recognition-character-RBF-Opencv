/*
* File:   eigen_jacobi.h
* Author: Olivier
*
* Created on 27 june 2014, 17:00
* Note: based on copyleft implementation of jacobi method to find eigen values fond on the web and adapted to GST needs
*/

#ifndef eigen_jacobi_H
#define    eigen_jacobi_H

#include <math.h>
#include <armadillo>

#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif

namespace gst
{
    DLLEXP int jacobi(arma::fmat A, arma::fvec & e , arma::fmat & V);
}
#endif
