#include <stdint.h>
#include <vector>

#ifndef XORSHIFT_H
#define XORSHIFT_H


#if defined(_WIN32)
    #define DLLEXP __declspec(dllexport)
#else
    #define DLLEXP
#endif


namespace gst
{
    class xorshift
    {
    public:
        DLLEXP xorshift(uint32_t inx, uint32_t iny, uint32_t inw, uint32_t inh)
        {
            this->x = inx;
            this->y = iny;
            this->w = inw;
            this->h = inh;
        }

        DLLEXP uint32_t getnext()
        {
            uint32_t t;

            t = x ^ (x << 11);
            x = y; y = h; h = w;
            return w = w ^ (w >> 19) ^ t ^ (t >> 8);
        }

        template <class T> DLLEXP std::vector<T> vrandperm(int n, int l)
        {
            std::vector<uint32_t> tmp;
            tmp.reserve(n);
            for (uint32_t i = 1 ; i <= n ; ++i) tmp.push_back(i);

            std::vector<T> v;
            v.reserve(l);

            int cnt = 0;
            while (!tmp.empty() && cnt++ < l)
            {
                int i = getnext() % tmp.size();
                v.push_back(T(tmp[i]));
                tmp.erase(tmp.begin() + i);
            }

            return v;
        }

        template <class T> DLLEXP std::vector<T> vrandperm(int n)
        {
            return vrandperm<T>(n, n);
        }

    private:
        uint32_t x=0, y=0, w=0, h=0;
    };
}

#endif /*XORSHIFT_H*/
